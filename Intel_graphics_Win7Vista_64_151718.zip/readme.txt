﻿
  Production Version Releases	
		
  Microsoft Windows Vista* 64	
  Microsoft Windows* 7 64
  Windows* Embedded Standard 7 64
                                               
  Driver Revision: 15.17.18.64.2555
					
  October 20, 2011
			
************************************************************
*
*  NOTE:  This document refers to systems containing the 
*             following Intel chipsets/processors:
*
*		
*		Intel(R) Pentium(R) Processor 
*		Intel(R) Core(TM) i3 Processor 
*		Intel(R) Core(TM) i5 Processor 
*		Intel(R) Core(TM) i3 Mobile Processor 
*		Intel(R) Core(TM) i5 Mobile Processor 
*		Intel(R) Core(TM) i7 Mobile Processor 
*		Intel(R) B43 Express Chipset 
*		Intel(R) G41 Express Chipset 
*		Intel(R) G43 Express Chipset 
*		Intel(R) G45 Express Chipset  
*		Intel(R) Q43 Express Chipset  
*		Intel(R) Q45 Express Chipset  
*		Mobile Intel(R) GL40 Express Chipset 
*		Mobile Intel(R) GM45 Express Chipset 
*		Mobile Intel(R) GS45 Express Chipset 
*
*    	                               
*	
*  Installation Information
*
*  This document makes references to products developed by
*  Intel. There are some restrictions on how these products
*  may be used, and what information may be disclosed to
*  others. Please read the Disclaimer section and contact
*  your Intel field representative if you would like more
*  information.
*
************************************************************
************************************************************
*  DISCLAIMER: Intel is making no claims of usability,
*  efficacy or warranty.  The INTEL SOFTWARE LICENSE
*  AGREEMENT contained herein completely defines the license
*  and use of this software.
*
*  This document contains information on products in the 
*  design phase of development. The information here is 
*  subject to change without notice. Do not finalize a 
*  design with this information.
************************************************************
************************************************************

Important Note:

Your computer is configured to run the WinSAT* test, which determines 
whether the computer can support the Windows Aero* desktop theme. 
The test will run after this driver is installed and the computer is restarted.
If your computer can support it, the Windows Aero desktop theme will 
automatically be enabled.


This test will take approximately 10 seconds.

************************************************************

*Other names and brands may be claimed as the property of others.
Copyright © 2011 Intel Corporation.  All rights reserved.