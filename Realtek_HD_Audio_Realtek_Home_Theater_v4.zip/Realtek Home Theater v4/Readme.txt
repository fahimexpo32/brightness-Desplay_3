        Realtek Semiconductor Corp. High Definition Audio System Software Ver: R2.59
                        Installation and Setup


Driver Installation/Removal Procedure For Realtek High Definition Audio Codec:
=================================================================================

<<< For Windows 2000/XP/Vista/Windows7 x86/x64 Driver >>>

---------------------------------------
Setup Driver at first time:
---------------------------------------
Windows 2000 , XP :
Step 1. Before installing the Realtek High Definition Audio Driver, Press the
        [Cancel] button if Windows detect the Multimedia Audio device. 
          
Step 2. Run the setup.exe program to start the installation. 
  
Step 3. Click on [Next] to continue the procedure. If the screen resolution is lower 
        than 1024*768,press [Yes] to continue the installation. If the Windows popup 
        "Digital Signature Not Found" message, press [Yes] to continue the 
        installation.
        
Step 4. Finally, select to restart the system and press [Finish] to complete
        the installation.  

Windows Vista, Windows7 :
Step 1. Run the setup.exe program to start the installation. 
  
Step 2. Click on [Next] to continue the procedure. If the screen resolution is lower 
        than 1024*768,press [Yes] to continue the installation. If the Windows popup 
        "Windows can't verify the publisher of this driver software" message, 
        press "Install this driver software anyway" to continue the installation.
        
Step 3. Finally, select to restart the system and press [Finish] to complete
        the installation.  

--------------------------
Update Driver:
--------------------------
Windows 2000 , XP :
Step 1. Follow Step 2,3,4 described in [Setup at first time] above to complete
        the procedure.

Windows Vista, Windows7 :
Step 1. Run setup.exe, it will remove the original driver in your system.

Step 2. Click "Next" to remove the original audio driver in your system.

Step 3. Once after the original driver removed , reboot the computer.

Step 4. Please go back to the new driver package after computer restarted.

Step 5. Run setup.exe, it will install the new audio driver then.

--------------------------
Remove Driver:
--------------------------
Windows 2000 , XP :
Step 1. Go to Start\Settings\Control Panel.

Step 2. Select [Add or Remove Programs] icon.

Step 3. Select "Realtek High Definition Audio Driver" and press [Remove]
        button.

Step 4. Click on [Yes] to finish the uninstallation.        

Step 5. At the end of the procedure, select to restart the system and press
        [Finish] to complete the uninstallation.

Windows Vista, Windows7 :
Step 1. Go to Start\Settings\Control Panel.

Step 2. Select [Programs] icon.

Step 3. Select [Programs and Features] icon.

Step 4. Select "Realtek High Definition Audio Driver" and press [uninstall] button.

Step 5. Click on [Yes] to finish the uninstallation.        

Step 6. At the end of the procedure, select to restart the system and press
        [Finish] to complete the uninstallation.


<< Other Information >>

--------------------
Silent Installation:
--------------------

Run "Setup.exe /s /f2<path\LogFile> /z[-rp<path\LogFile>]"
i.e. setup.exe /s /f2c:\mylog.log /z[-rpC:\RHDSetup.log]

--------------------
Silent Uninstallation:
--------------------

Run "Setup.exe /removeonly /s /f1<path\USetup.iss> /f2<path\LogFile> /z[-rp<path\LogFile>]"
i.e. setup.exe /removeonly /s /f1C:\AudioDriver\USetup.iss /f2c:\mylog.log /z[-rpC:\RHDSetup.log]


Note: 1. Please update Directx version to DirectX8.1 or above.

---------------------
Version Informations:
---------------------
If driver package include below drivers :
-----------------------------------------------------------------------
Windows 2000/XP :
RTKHDA64.sys                                        : 5.10.0.6343
RTKHDAUD.sys                                        : 5.10.0.6343
Alcmtr.exe                                          : 1.6.0.4
AlcWzrd.exe                                         : 1.1.0.37
MicCal.exe                                          : 1.1.2.4
RTHDCPL.exe                                         : 2.3.9.2
RtkAudioService.exe                                 : 1.0.0.19
RtkAudioService64.exe                               : 1.0.0.19
RTLCPL.exe                                          : 1.0.1.66
RtlUpd.exe                                          : 2.8.0.3
RtlUpd64.exe                                        : 2.8.0.3
SkyTel.exe                                          : 2.0.2.0
SoundMan.exe                                        : 1.0.0.32
vncutil.exe                                         : 1.0.0.38
vncutil64.exe                                       : 1.0.0.38
AMBFilt.sys                                         : 5.10.0.4240
AMBFt64.sys                                         : 5.10.0.4240
Monfilt.sys                                         : 5.10.0.4112
Monft64.sys                                         : 5.10.0.4115
OAO17Afx.sys                                        : 1.0.7.3
ALSndMgr.cpl                                        : 1.0.0.11
RTSndMgr.cpl                                        : 1.0.1.6
RCoInst64XP.dll                                     : 1.1.2.2
RTCOMDLL.dll                                        : 1.0.0.112
RtkCoInstXP.dll                                     : 1.1.2.2
RtlCPAPI.dll                                        : 1.0.2.3

Vista/Win7 driver : --------------------------------------------------------
Vista/Win7 driver for x86
RTKVHDA.sys                                         : 6.0.1.6343
AERTSrv.exe                                         : 1.0.32.10
FMAPP.exe                                           : 1.32.0.1
RtHDVBg.exe                                         : 1.0.0.63
RtHDVCpl.exe                                        : 1.0.0.653
RtkAudioService.exe                                 : 1.0.0.28
RtkNGUI.exe                                         : 1.0.0.102
RtlUpd.exe                                          : 2.8.0.3
SkyTel.exe                                          : 2.0.2.2
vncutil.exe                                         : 1.0.0.43
mbfilt32.sys                                        : 6.10.0.8
RTSndMgr.cpl                                        : 1.0.0.19
AERTACap.dll                                        : 2.0.32.13
AERTARen.dll                                        : 1.0.32.9
BlackSkinImages.dll                                 : 1.0.0.102
DarkSkinImages.dll                                  : 1.0.0.102
DTSBassEnhancementDLL.dll                           : 1.0.0.1
DTSBoostDLL.dll                                     : 1.0.0.1
DTSGainCompensatorDLL.dll                           : 1.0.0.1
DTSGFXAPO.dll                                       : 1.0.0.3
DTSGFXAPONS.dll                                     : 1.0.0.3
DTSLFXAPO.dll                                       : 1.0.0.3
DTSLimiterDLL.dll                                   : 1.0.0.1
DTSNeoPCDLL.dll                                     : 1.0.0.1
DTSS2HeadphoneDLL.dll                               : 1.0.0.1
DTSS2SpeakerDLL.dll                                 : 1.0.0.1
DTSSymmetryDLL.dll                                  : 1.0.0.1
DTSVoiceClarityDLL.dll                              : 1.0.0.1
FMAPO.dll                                           : 43.5.14.65
GrayJadeSkinImages.dll                              : 1.0.0.102
LightSkinImages.dll                                 : 1.0.0.102
MaxxAudioAPO.dll                                    : 1.2.2.0
MaxxAudioAPO20.dll                                  : 2.2.9.0
MaxxAudioAPO30.dll                                  : 3.2.1.1
MaxxAudioEQ.dll                                     : 5.9.7.0
MaxxAudioRealtek.dll                                : 1.2.0.0
MaxxAudioRealtek2.dll                               : 1.0.7.0
MaxxVolumeSDAPO.dll                                 : 3.1.0.0
MBAPO32.dll                                         : 1.0.43.0
MBPPCn32.dll                                        : 1.0.0.110
MBppld32.dll                                        : 1.0.43.0
MBTHX32.dll                                         : 1.0.15.132
MBWrp32.dll                                         : 1.0.0.180
R4EEA32A.dll                                        : 7.2.7000.5
R4EED32A.dll                                        : 7.2.7000.5
R4EEG32A.dll                                        : 7.2.7000.5
R4EEL32A.dll                                        : 7.2.7000.5
R4EEP32A.dll                                        : 7.2.7000.5
RP3DAA32.dll                                        : 6.0.6001.18
RP3DHT32.dll                                        : 6.0.6001.18
RTCOMDLL.dll                                        : 2.0.0.144
RTEED32A.dll                                        : 6.1.6001.33
RTEEG32A.dll                                        : 6.1.6001.33
RTEEL32A.dll                                        : 6.1.6001.33
RTEEP32A.dll                                        : 6.1.6001.33
RtkAPO.dll                                          : 11.0.6000.209
RtkApoApi.dll                                       : 1.0.0.36
RtkCfg.dll                                          : 1.0.0.2
RtkCoInst.dll                                       : 1.1.2.2
RtkGuiCompLib.dll                                   : 1.0.0.2
RtkPgExt.dll                                        : 6.0.6000.198
RtlCPAPI.dll                                        : 1.0.2.4
SFAPO.dll                                           : 3.0.0.11
SFCOM.dll                                           : 3.0.0.11
SFFXComm.dll                                        : 2.0.0.13
SFFXDAPO.dll                                        : 2.0.0.13
SFFXHAPO.dll                                        : 2.0.0.13
SFFXProc.dll                                        : 2.0.0.13
SFFXSAPO.dll                                        : 2.0.0.13
SFNHK.dll                                           : 3.0.0.11
slcc3d32.dll                                        : 1.0.0.100
slcshp32.dll                                        : 1.0.3.0
slcsii32.dll                                        : 1.0.3.0
slgeq32.dll                                         : 1.0.1.0
slh36032.dll                                        : 1.0.2.0
slhlim32.dll                                        : 2.1.0.0
slInit32.dll                                        : 1.1.3.0
slmaxv32.dll                                        : 1.2.1.0
sltshd32.dll                                        : 1.2.0.0
sluapo32.dll                                        : 2.2.2.0
slvipp32.dll                                        : 1.0.1.0
slviq32.dll                                         : 2.1.0.0
SRSHP360.dll                                        : 1.1.0.0
SRSTSHD.dll                                         : 1.1.4.0
SRSTSXT.dll                                         : 3.2.0.0
SRSWOW.dll                                          : 1.1.3.0
tadefxapo.dll                                       : 1.0.1.12
tosade.dll                                          : 1.0.1.12
WavesGUILib.dll                                     : 1.2.0.0
WavesLib.dll                                        : 5.9.7.0
RCORES.dat                                          : 1.0.7.5

Vista/Win7 driver for x64
RTKVHD64.sys                                        : 6.0.1.6343
AERTSr64.exe                                        : 1.0.64.10
FMAPP.exe                                           : 1.64.0.1
RAVBg64.exe                                         : 1.0.0.63
RAVCpl64.exe                                        : 1.0.0.653
RtkAudioService64.exe                               : 1.0.0.28
RtkNGUI64.exe                                       : 1.0.0.102
RtlUpd64.exe                                        : 2.8.0.3
SkyTel.exe                                          : 2.0.2.2
vncutil64.exe                                       : 1.0.0.43
GWfilt64.sys                                        : 6.10.0.3
mbfilt64.sys                                        : 6.10.0.8
RTSnMg64.cpl                                        : 1.0.0.19
AERTAC64.dll                                        : 2.0.64.13
AERTAR64.dll                                        : 1.0.64.9
BlackSkinImages64.dll                               : 1.0.0.102
DarkSkinImages64.dll                                : 1.0.0.102
DTSBassEnhancementDLL64.dll                         : 1.0.0.1
DTSBoostDLL64.dll                                   : 1.0.0.1
DTSGainCompensatorDLL64.dll                         : 1.0.0.1
DTSGFXAPO64.dll                                     : 1.0.0.3
DTSGFXAPONS64.dll                                   : 1.0.0.3
DTSLFXAPO64.dll                                     : 1.0.0.3
DTSLimiterDLL64.dll                                 : 1.0.0.1
DTSNeoPCDLL64.dll                                   : 1.0.0.1
DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
DTSS2SpeakerDLL64.dll                               : 1.0.0.1
DTSSymmetryDLL64.dll                                : 1.0.0.1
DTSVoiceClarityDLL64.dll                            : 1.0.0.1
FMAPO64.dll                                         : 43.6.14.65
GrayJadeSkinImages64.dll                            : 1.0.0.102
LightSkinImages64.dll                               : 1.0.0.102
MaxxAudioAPO20.dll                                  : 2.2.9.0
MaxxAudioAPO30.dll                                  : 3.2.1.1
MaxxAudioEQ.dll                                     : 5.9.7.0
MaxxAudioRealtek.dll                                : 1.2.0.0
MaxxAudioRealtek2.dll                               : 1.0.7.0
MaxxVolumeSDAPO.dll                                 : 3.1.0.0
MBAPO32.dll                                         : 1.0.43.0
MBAPO64.dll                                         : 1.0.43.0
MBPPCn64.dll                                        : 1.0.0.110
MBppld64.dll                                        : 1.0.43.0
MBTHX32.dll                                         : 1.0.15.132
MBTHX64.dll                                         : 1.0.15.132
MBWrp64.dll                                         : 1.0.0.180
R4EEA64A.dll                                        : 7.2.7000.5
R4EED64A.dll                                        : 7.2.7000.5
R4EEG64A.dll                                        : 7.2.7000.5
R4EEL64A.dll                                        : 7.2.7000.5
R4EEP64A.dll                                        : 7.2.7000.5
RCoInst64.dll                                       : 1.1.2.2
RP3DAA64.dll                                        : 6.0.6001.18
RP3DHT64.dll                                        : 6.0.6001.18
RtCOM64.dll                                         : 2.0.0.144
RTCOMDLL.dll                                        : 2.0.0.144
RTEED64A.dll                                        : 6.1.6001.33
RTEEG64A.dll                                        : 6.1.6001.33
RTEEL64A.dll                                        : 6.1.6001.33
RTEEP64A.dll                                        : 6.1.6001.33
RtkApi64.dll                                        : 1.0.0.36
RtkAPO64.dll                                        : 11.0.6000.209
RtkCfg.dll                                          : 1.0.0.1
RtkCfg64.dll                                        : 1.0.0.2
RtkGuiCompLib.dll                                   : 1.0.0.2
RtlCPAPI.dll                                        : 1.0.2.4
RtlCPAPI64.dll                                      : 1.0.2.4
RtPgEx64.dll                                        : 6.0.6000.198
SFAPO64.dll                                         : 3.0.0.11
SFCOM.dll                                           : 3.0.0.11
SFCOM64.dll                                         : 3.0.0.11
SFComm64.dll                                        : 2.0.0.13
SFDAPO64.dll                                        : 2.0.0.13
SFHAPO64.dll                                        : 2.0.0.13
SFNHK64.dll                                         : 3.0.0.11
SFProc64.dll                                        : 2.0.0.13
SFSAPO64.dll                                        : 2.0.0.13
SFSS_APO.dll                                        : 1.0.0.11110
slcc3d64.dll                                        : 1.0.0.100
slcshp64.dll                                        : 1.0.3.0
slcsii64.dll                                        : 1.0.3.0
slgeq64.dll                                         : 1.0.1.0
slh36064.dll                                        : 1.0.2.0
slhlim64.dll                                        : 2.1.0.0
slInit64.dll                                        : 1.1.3.0
slmaxv64.dll                                        : 1.2.1.0
sltshd64.dll                                        : 1.2.0.0
sluapo64.dll                                        : 2.2.2.0
slvipp64.dll                                        : 1.0.1.0
slviq64.dll                                         : 2.1.0.0
SRSHP64.dll                                         : 1.1.0.0
SRSTSH64.dll                                        : 1.1.4.0
SRSTSX64.dll                                        : 3.2.0.0
SRSWOW64.dll                                        : 1.1.3.0
tadefxapo.dll                                       : 1.0.1.12
tosade.dll                                          : 1.0.1.12
WavesGUILib.dll                                     : 1.2.0.0
RCORES64.dat                                        : 1.0.7.5

HDMI Driver : ---------------------------------------------------------
Vista/Win7 x86:
RtHDMIV.sys                                         : 6.0.1.6251
RtkAudioSrvATI.exe                                  : 1.0.0.23
RtkUpd.exe                                          : 2.8.0.3
RH3DAA32.dll                                        : 6.0.6001.18
RH3DHT32.dll                                        : 6.0.6001.18
RHCoInst.dll                                        : 1.1.1.2
RHDMIExt.dll                                        : 6.0.6000.172
RTEED32H.dll                                        : 6.1.6001.33
RTEEG32H.dll                                        : 6.1.6001.33
RTEEL32H.dll                                        : 6.1.6001.33
RTEEP32H.dll                                        : 6.1.6001.33
RtkHDMI.dll                                         : 11.0.6000.183

Vista/Win7 x64:
RtHDMIVX.sys                                        : 6.0.1.6251
RtkAudioSrvATI64.exe                                : 1.0.0.23
RtkUpd64.exe                                        : 2.8.0.3
RH3DAA64.dll                                        : 6.0.6001.18
RH3DHT64.dll                                        : 6.0.6001.18
RHCoInst64.dll                                      : 1.1.1.2
RHDMEx64.dll                                        : 6.0.6000.172
RTEED64H.dll                                        : 6.1.6001.33
RTEEG64H.dll                                        : 6.1.6001.33
RTEEL64H.dll                                        : 6.1.6001.33
RTEEP64H.dll                                        : 6.1.6001.33
RtkHDM64.dll                                        : 11.0.6000.183

XP/2K x86:
RtkHDMI.sys                                         : 5.10.0.6251
Rtaupd.exe                                          : 2.8.0.3
RHCoInstXP.dll                                      : 1.1.1.2

XP/2K x64:
RtkHDMIX.sys                                        : 5.10.0.6251
Rtaupd64.exe                                        : 2.8.0.3
RHCoInst64XP.dll                                    : 1.1.1.2


Driver Setup Program                                : 3.20

--------
History:
--------
Driver Package R2.59
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC672, ALC680, ALC221, ALC231, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC672, ALC680 ALC221, ALC231, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013) For Windows 2000 SP4, XP SP1, XP SP2, Server 2003 SP1.
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6343
  RTKHDAUD.sys                                        : 5.10.0.6343
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.9.2
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.3
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64XP.dll                                     : 1.1.2.2
  RTCOMDLL.dll                                        : 1.0.0.112
  RtkCoInstXP.dll                                     : 1.1.2.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6343
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.63
  RtHDVCpl.exe                                        : 1.0.0.653
  RtkAudioService.exe                                 : 1.0.0.28
  RtkNGUI.exe                                         : 1.0.0.102
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.43
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.102
  DarkSkinImages.dll                                  : 1.0.0.102
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 43.5.14.65
  GrayJadeSkinImages.dll                              : 1.0.0.102
  LightSkinImages.dll                                 : 1.0.0.102
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.132
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.2.7000.5
  R4EED32A.dll                                        : 7.2.7000.5
  R4EEG32A.dll                                        : 7.2.7000.5
  R4EEL32A.dll                                        : 7.2.7000.5
  R4EEP32A.dll                                        : 7.2.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.144
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.209
  RtkApoApi.dll                                       : 1.0.0.36
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.2.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.198
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcc3d32.dll                                        : 1.0.0.100
  slcshp32.dll                                        : 1.0.3.0
  slcsii32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slhlim32.dll                                        : 2.1.0.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.2.1.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 2.2.2.0
  slvipp32.dll                                        : 1.0.1.0
  slviq32.dll                                         : 2.1.0.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  tadefxapo.dll                                       : 1.0.1.12
  tosade.dll                                          : 1.0.1.12
  WavesGUILib.dll                                     : 1.2.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6343
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.63
  RAVCpl64.exe                                        : 1.0.0.653
  RtkAudioService64.exe                               : 1.0.0.28
  RtkNGUI64.exe                                       : 1.0.0.102
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.43
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.102
  DarkSkinImages64.dll                                : 1.0.0.102
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 43.6.14.65
  GrayJadeSkinImages64.dll                            : 1.0.0.102
  LightSkinImages64.dll                               : 1.0.0.102
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBAPO64.dll                                         : 1.0.43.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.132
  MBTHX64.dll                                         : 1.0.15.132
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.2.7000.5
  R4EED64A.dll                                        : 7.2.7000.5
  R4EEG64A.dll                                        : 7.2.7000.5
  R4EEL64A.dll                                        : 7.2.7000.5
  R4EEP64A.dll                                        : 7.2.7000.5
  RCoInst64.dll                                       : 1.1.2.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.144
  RTCOMDLL.dll                                        : 2.0.0.144
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.36
  RtkAPO64.dll                                        : 11.0.6000.209
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.198
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.11110
  slcc3d64.dll                                        : 1.0.0.100
  slcshp64.dll                                        : 1.0.3.0
  slcsii64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slhlim64.dll                                        : 2.1.0.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.2.1.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 2.2.2.0
  slvipp64.dll                                        : 1.0.1.0
  slviq64.dll                                         : 2.1.0.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  tadefxapo.dll                                       : 1.0.1.12
  tosade.dll                                          : 1.0.1.12
  WavesGUILib.dll                                     : 1.2.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6251
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.1.1.2
  RHDMIExt.dll                                        : 6.0.6000.172
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.183

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6251
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.1.1.2
  RHDMEx64.dll                                        : 6.0.6000.172
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.183

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6251
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.1.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6251
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.1.1.2

  Driver Setup Program                                : 3.20
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.58
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013) For Windows 2000 SP4, XP SP1, XP SP2, Server 2003 SP1.
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6316
  RtkHDAud.sys                                        : 5.10.0.6316
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.8.7
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64XP.dll                                     : 1.1.1.2
  RTCOMDLL.dll                                        : 1.0.0.112
  RtkCoInstXP.dll                                     : 1.1.1.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6316
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.58
  RtHDVCpl.exe                                        : 1.0.0.647
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.99
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.41
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.99
  DarkSkinImages.dll                                  : 1.0.0.99
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 43.5.14.65
  GrayJadeSkinImages.dll                              : 1.0.0.99
  LightSkinImages.dll                                 : 1.0.0.99
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.130
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.1.7000.5
  R4EED32A.dll                                        : 7.1.7000.5
  R4EEG32A.dll                                        : 7.1.7000.5
  R4EEL32A.dll                                        : 7.1.7000.5
  R4EEP32A.dll                                        : 7.1.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.143
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.201
  RtkApoApi.dll                                       : 1.0.0.34
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.1.6
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.192
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcc3d32.dll                                        : 1.0.0.100
  slcshp32.dll                                        : 1.0.3.0
  slcsii32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slhlim32.dll                                        : 2.1.0.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.2.1.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 2.2.2.0
  slvipp32.dll                                        : 1.0.1.0
  slviq32.dll                                         : 2.1.0.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6316
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.58
  RAVCpl64.exe                                        : 1.0.0.647
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.99
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.41
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.99
  DarkSkinImages64.dll                                : 1.0.0.99
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 43.6.14.65
  GrayJadeSkinImages64.dll                            : 1.0.0.99
  LightSkinImages64.dll                               : 1.0.0.99
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBAPO64.dll                                         : 1.0.43.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.130
  MBTHX64.dll                                         : 1.0.15.130
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.1.7000.5
  R4EED64A.dll                                        : 7.1.7000.5
  R4EEG64A.dll                                        : 7.1.7000.5
  R4EEL64A.dll                                        : 7.1.7000.5
  R4EEP64A.dll                                        : 7.1.7000.5
  RCoInst64.dll                                       : 1.1.1.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.143
  RTCOMDLL.dll                                        : 2.0.0.143
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.34
  RtkAPO64.dll                                        : 11.0.6000.201
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.192
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.11110
  slcc3d64.dll                                        : 1.0.0.100
  slcshp64.dll                                        : 1.0.3.0
  slcsii64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slhlim64.dll                                        : 2.1.0.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.2.1.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 2.2.2.0
  slvipp64.dll                                        : 1.0.1.0
  slviq64.dll                                         : 2.1.0.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6251
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.1.1.2
  RHDMIExt.dll                                        : 6.0.6000.172
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.183

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6251
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.1.1.2
  RHDMEx64.dll                                        : 6.0.6000.172
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.183

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6251
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.1.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6251
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.1.1.2

  Driver Setup Program                                : 3.18
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.57
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        2.) Package :
            1. Realtek Setup program will update audio driver automatically in update Realtek audio driver case under Vista/Windows 7.
               Realtek setup program will un-install the previous version Realatek audio driver on the system first.
               And it will re-install Realtek audio driver automatically after system re-boot.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6299
  RtkHDAud.sys                                        : 5.10.0.6299
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.8.5
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64XP.dll                                     : 1.1.1.2
  RTCOMDLL.dll                                        : 1.0.0.112
  RtkCoInstXP.dll                                     : 1.1.1.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6299
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.58
  RtHDVCpl.exe                                        : 1.0.0.637
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.96
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.96
  DarkSkinImages.dll                                  : 1.0.0.96
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.38.65
  GrayJadeSkinImages.dll                              : 1.0.0.96
  LightSkinImages.dll                                 : 1.0.0.96
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.129
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.1.7000.5
  R4EED32A.dll                                        : 7.1.7000.5
  R4EEG32A.dll                                        : 7.1.7000.5
  R4EEL32A.dll                                        : 7.1.7000.5
  R4EEP32A.dll                                        : 7.1.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.198
  RtkApoApi.dll                                       : 1.0.0.33
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.1.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.190
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcc3d32.dll                                        : 1.0.0.100
  slcshp32.dll                                        : 1.0.3.0
  slcsii32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slhlim32.dll                                        : 2.1.0.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.2.1.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 2.2.2.0
  slvipp32.dll                                        : 1.0.1.0
  slviq32.dll                                         : 2.1.0.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6299
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.58
  RAVCpl64.exe                                        : 1.0.0.637
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.96
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.96
  DarkSkinImages64.dll                                : 1.0.0.96
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.38.65
  GrayJadeSkinImages64.dll                            : 1.0.0.96
  LightSkinImages64.dll                               : 1.0.0.96
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBAPO64.dll                                         : 1.0.43.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.129
  MBTHX64.dll                                         : 1.0.15.129
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.1.7000.5
  R4EED64A.dll                                        : 7.1.7000.5
  R4EEG64A.dll                                        : 7.1.7000.5
  R4EEL64A.dll                                        : 7.1.7000.5
  R4EEP64A.dll                                        : 7.1.7000.5
  RCoInst64.dll                                       : 1.1.1.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.142
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.33
  RtkAPO64.dll                                        : 11.0.6000.198
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.190
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.11110
  slcc3d64.dll                                        : 1.0.0.100
  slcshp64.dll                                        : 1.0.3.0
  slcsii64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slhlim64.dll                                        : 2.1.0.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.2.1.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 2.2.2.0
  slvipp64.dll                                        : 1.0.1.0
  slviq64.dll                                         : 2.1.0.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6251
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.1.1.2
  RHDMIExt.dll                                        : 6.0.6000.172
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.183

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6251
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.1.1.2
  RHDMEx64.dll                                        : 6.0.6000.172
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.183

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6251
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.1.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6251
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.1.1.2

  Driver Setup Program                                : 3.15
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.56
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6278
  RtkHDAud.sys                                        : 5.10.0.6278
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.8.0
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.6
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.1.1.2
  RTCOMDLL.dll                                        : 1.0.0.112
  RtkCoInstXP.dll                                     : 1.1.1.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6278
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.55
  RtHDVCpl.exe                                        : 1.0.0.629
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.89
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.89
  DarkSkinImages.dll                                  : 1.0.0.89
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 43.5.7.65
  GrayJadeSkinImages.dll                              : 1.0.0.89
  LightSkinImages.dll                                 : 1.0.0.89
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.127
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.1.7000.5
  R4EED32A.dll                                        : 7.1.7000.5
  R4EEG32A.dll                                        : 7.1.7000.5
  R4EEL32A.dll                                        : 7.1.7000.5
  R4EEP32A.dll                                        : 7.1.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.193
  RtkApoApi.dll                                       : 1.0.0.32
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.1.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.181
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcc3d32.dll                                        : 1.0.0.100
  slcshp32.dll                                        : 1.0.3.0
  slcsii32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slhlim32.dll                                        : 2.1.0.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.2.1.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 2.2.0.0
  slvipp32.dll                                        : 1.0.1.0
  slviq32.dll                                         : 2.1.0.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6278
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.55
  RAVCpl64.exe                                        : 1.0.0.629
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.89
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.89
  DarkSkinImages64.dll                                : 1.0.0.89
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 43.6.7.65
  GrayJadeSkinImages64.dll                            : 1.0.0.89
  LightSkinImages64.dll                               : 1.0.0.89
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.43.0
  MBAPO64.dll                                         : 1.0.43.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.43.0
  MBTHX32.dll                                         : 1.0.15.127
  MBTHX64.dll                                         : 1.0.15.127
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.1.7000.5
  R4EED64A.dll                                        : 7.1.7000.5
  R4EEG64A.dll                                        : 7.1.7000.5
  R4EEL64A.dll                                        : 7.1.7000.5
  R4EEP64A.dll                                        : 7.1.7000.5
  RCoInst64.dll                                       : 1.1.1.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.142
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.32
  RtkAPO64.dll                                        : 11.0.6000.193
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.181
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.11110
  slcc3d64.dll                                        : 1.0.0.100
  slcshp64.dll                                        : 1.0.3.0
  slcsii64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slhlim64.dll                                        : 2.1.0.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.2.1.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 2.2.0.0
  slvipp64.dll                                        : 1.0.1.0
  slviq64.dll                                         : 2.1.0.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6251
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.1.1.2
  RHDMIExt.dll                                        : 6.0.6000.172
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.183

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6251
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.1.1.2
  RHDMEx64.dll                                        : 6.0.6000.172
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.183

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6251
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.1.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6251
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.1.1.2

  Driver Setup Program                                : 3.14
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.55
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6257
  RtkHDAud.sys                                        : 5.10.0.6257
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.7.5
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.3
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64XP.dll                                     : 1.1.1.2
  RTCOMDLL.dll                                        : 1.0.0.112
  RtkCoInstXP.dll                                     : 1.1.1.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6257
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.54
  RtHDVCpl.exe                                        : 1.0.0.617
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.81
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.81
  DarkSkinImages.dll                                  : 1.0.0.81
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 43.5.7.65
  GrayJadeSkinImages.dll                              : 1.0.0.81
  LightSkinImages.dll                                 : 1.0.0.81
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.123
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.1.7000.5
  R4EED32A.dll                                        : 7.1.7000.5
  R4EEG32A.dll                                        : 7.1.7000.5
  R4EEL32A.dll                                        : 7.1.7000.5
  R4EEP32A.dll                                        : 7.1.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.184
  RtkApoApi.dll                                       : 1.0.0.32
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.1.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.173
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  slvipp32.dll                                        : 1.0.1.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6257
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.54
  RAVCpl64.exe                                        : 1.0.0.617
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.81
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.81
  DarkSkinImages64.dll                                : 1.0.0.81
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 43.6.7.65
  GrayJadeSkinImages64.dll                            : 1.0.0.81
  LightSkinImages64.dll                               : 1.0.0.81
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.2.0.0
  MaxxAudioRealtek2.dll                               : 1.0.7.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBAPO64.dll                                         : 1.0.41.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.123
  MBTHX64.dll                                         : 1.0.15.123
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.1.7000.5
  R4EED64A.dll                                        : 7.1.7000.5
  R4EEG64A.dll                                        : 7.1.7000.5
  R4EEL64A.dll                                        : 7.1.7000.5
  R4EEP64A.dll                                        : 7.1.7000.5
  RCoInst64.dll                                       : 1.1.1.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.142
  RTCOMDLL.dll                                        : 2.0.0.142
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.32
  RtkAPO64.dll                                        : 11.0.6000.184
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.173
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.11110
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  slvipp64.dll                                        : 1.0.1.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6251
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.1.1.2
  RHDMIExt.dll                                        : 6.0.6000.172
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.183

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6251
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.1.1.2
  RHDMEx64.dll                                        : 6.0.6000.172
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.183

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6251
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.1.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6251
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.1.1.2

  Driver Setup Program                                : 3.14
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.54
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC887, ALC888, ALC889, ALC892, ALC899, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC670, ALC680 ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6235
  RtkHDAud.sys                                        : 5.10.0.6235
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.7.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64XP.dll                                     : 1.1.1.0
  RTCOMDLL.dll                                        : 1.0.0.110
  RtkCoInstXP.dll                                     : 1.1.1.0
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6235
  AERTSrv.exe                                         : 1.0.32.10
  FMAPP.exe                                           : 1.32.0.1
  RtHDVBg.exe                                         : 1.0.0.51
  RtHDVCpl.exe                                        : 1.0.0.603
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.76
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.76
  DarkSkinImages.dll                                  : 1.0.0.76
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 43.5.6.68
  GrayJadeSkinImages.dll                              : 1.0.0.76
  LightSkinImages.dll                                 : 1.0.0.76
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.1.0.0
  MaxxAudioRealtek2.dll                               : 1.0.3.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.122
  MBWrp32.dll                                         : 1.0.0.180
  R4EEA32A.dll                                        : 7.1.7000.5
  R4EED32A.dll                                        : 7.1.7000.5
  R4EEG32A.dll                                        : 7.1.7000.5
  R4EEL32A.dll                                        : 7.1.7000.5
  R4EEP32A.dll                                        : 7.1.7000.5
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.140
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.178
  RtkApoApi.dll                                       : 1.0.0.31
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.1.1
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.165
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  slvipp32.dll                                        : 1.0.1.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.1.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6235
  AERTSr64.exe                                        : 1.0.64.10
  FMAPP.exe                                           : 1.64.0.1
  RAVBg64.exe                                         : 1.0.0.51
  RAVCpl64.exe                                        : 1.0.0.603
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.76
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.76
  DarkSkinImages64.dll                                : 1.0.0.76
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 43.6.6.68
  GrayJadeSkinImages64.dll                            : 1.0.0.76
  LightSkinImages64.dll                               : 1.0.0.76
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.1.1
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.1.0.0
  MaxxAudioRealtek2.dll                               : 1.0.3.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBAPO64.dll                                         : 1.0.41.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.122
  MBTHX64.dll                                         : 1.0.15.122
  MBWrp64.dll                                         : 1.0.0.180
  R4EEA64A.dll                                        : 7.1.7000.5
  R4EED64A.dll                                        : 7.1.7000.5
  R4EEG64A.dll                                        : 7.1.7000.5
  R4EEL64A.dll                                        : 7.1.7000.5
  R4EEP64A.dll                                        : 7.1.7000.5
  RCoInst64.dll                                       : 1.1.1.1
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.140
  RTCOMDLL.dll                                        : 2.0.0.140
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.31
  RtkAPO64.dll                                        : 11.0.6000.178
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.165
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.10280
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  slvipp64.dll                                        : 1.0.1.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.1.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 3.13
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.53
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6215
  RtkHDAud.sys                                        : 5.10.0.6215
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.7.2
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64.dll                                       : 1.1.0.3
  RCoInst64XP.dll                                     : 1.1.0.4
  RTCOMDLL.dll                                        : 1.0.0.108
  RtkCoInst.dll                                       : 1.1.0.3
  RtkCoInstXP.dll                                     : 1.1.0.4
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6215
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.46
  RtHDVCpl.exe                                        : 1.0.0.590
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.65
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.65
  DarkSkinImages.dll                                  : 1.0.0.65
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.3
  DTSGFXAPONS.dll                                     : 1.0.0.3
  DTSLFXAPO.dll                                       : 1.0.0.3
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.35.67
  GrayJadeSkinImages.dll                              : 1.0.0.65
  LightSkinImages.dll                                 : 1.0.0.65
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.2.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.122
  MBWrp32.dll                                         : 1.0.0.180
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.137
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.168
  RtkApoApi.dll                                       : 1.0.0.28
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.0.8
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.159
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  slvipp32.dll                                        : 1.0.1.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6215
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.46
  RAVCpl64.exe                                        : 1.0.0.590
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.65
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.65
  DarkSkinImages64.dll                                : 1.0.0.65
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.3
  DTSGFXAPONS64.dll                                   : 1.0.0.3
  DTSLFXAPO64.dll                                     : 1.0.0.3
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.35.67
  GrayJadeSkinImages64.dll                            : 1.0.0.65
  LightSkinImages64.dll                               : 1.0.0.65
  MaxxAudioAPO20.dll                                  : 2.2.9.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.2.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.41.0
  MBAPO64.dll                                         : 1.0.41.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.41.0
  MBTHX32.dll                                         : 1.0.15.122
  MBTHX64.dll                                         : 1.0.15.122
  MBWrp64.dll                                         : 1.0.0.180
  RCoInst64.dll                                       : 1.1.0.8
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.137
  RTCOMDLL.dll                                        : 2.0.0.137
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.28
  RtkAPO64.dll                                        : 11.0.6000.168
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.159
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.8310
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  slvipp64.dll                                        : 1.0.1.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 3.10
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.52
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6194
  RtkHDAud.sys                                        : 5.10.0.6194
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.6.9
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.6
  RCoInst64.dll                                       : 1.1.0.3
  RCoInst64XP.dll                                     : 1.1.0.3
  RTCOMDLL.dll                                        : 1.0.0.108
  RtkCoInst.dll                                       : 1.1.0.3
  RtkCoInstXP.dll                                     : 1.1.0.3
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6194
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.41
  RtHDVCpl.exe                                        : 1.0.0.576
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.57
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.40
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.57
  DarkSkinImages.dll                                  : 1.0.0.57
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.2
  DTSGFXAPONS.dll                                     : 1.0.0.2
  DTSLFXAPO.dll                                       : 1.0.0.2
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.35.66
  GrayJadeSkinImages.dll                              : 1.0.0.57
  LightSkinImages.dll                                 : 1.0.0.57
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.2.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.40.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.40.0
  MBTHX32.dll                                         : 1.0.15.120
  MBWrp32.dll                                         : 1.0.0.180
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.137
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.165
  RtkApoApi.dll                                       : 1.0.0.24
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.0.3
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtkPgExt.dll                                        : 6.0.6000.152
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  slvipp32.dll                                        : 1.0.1.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6194
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.41
  RAVCpl64.exe                                        : 1.0.0.576
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.57
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.40
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.57
  DarkSkinImages64.dll                                : 1.0.0.57
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.2
  DTSGFXAPONS64.dll                                   : 1.0.0.2
  DTSLFXAPO64.dll                                     : 1.0.0.2
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.35.66
  GrayJadeSkinImages64.dll                            : 1.0.0.57
  LightSkinImages64.dll                               : 1.0.0.57
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.2.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.40.0
  MBAPO64.dll                                         : 1.0.40.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.40.0
  MBTHX32.dll                                         : 1.0.15.120
  MBTHX64.dll                                         : 1.0.15.120
  MBWrp64.dll                                         : 1.0.0.180
  RCoInst64.dll                                       : 1.1.0.3
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.137
  RTCOMDLL.dll                                        : 2.0.0.137
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.24
  RtkAPO64.dll                                        : 11.0.6000.165
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.152
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  SFSS_APO.dll                                        : 1.0.0.8020
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  slvipp64.dll                                        : 1.0.1.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 3.07
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.51
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6167
  RtkHDAud.sys                                        : 5.10.0.6167
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.6.2
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.5
  RCoInst64XP.dll                                     : 1.0.9.9
  RTCOMDLL.dll                                        : 1.0.0.108
  RtkCoInstXP.dll                                     : 1.0.9.9
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6167
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.40
  RtHDVCpl.exe                                        : 1.0.0.553
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.53
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.13
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.53
  DarkSkinImages.dll                                  : 1.0.0.53
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.2
  DTSGFXAPONS.dll                                     : 1.0.0.2
  DTSLFXAPO.dll                                       : 1.0.0.2
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.32.66
  GrayJadeSkinImages.dll                              : 1.0.0.53
  LightSkinImages.dll                                 : 1.0.0.53
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.115
  MBWrp32.dll                                         : 1.0.0.180
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.136
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.160
  RtkApoApi.dll                                       : 1.0.0.21
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.0.0
  RtkGuiCompLib.dll                                   : 1.0.0.1
  RtkPgExt.dll                                        : 6.0.6000.141
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFFXComm.dll                                        : 2.0.0.13
  SFFXDAPO.dll                                        : 2.0.0.13
  SFFXHAPO.dll                                        : 2.0.0.13
  SFFXProc.dll                                        : 2.0.0.13
  SFFXSAPO.dll                                        : 2.0.0.13
  SFNHK.dll                                           : 3.0.0.11
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6167
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.40
  RAVCpl64.exe                                        : 1.0.0.553
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.53
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.13
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.53
  DarkSkinImages64.dll                                : 1.0.0.53
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.2
  DTSGFXAPONS64.dll                                   : 1.0.0.2
  DTSLFXAPO64.dll                                     : 1.0.0.2
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.32.66
  GrayJadeSkinImages64.dll                            : 1.0.0.53
  LightSkinImages64.dll                               : 1.0.0.53
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.2.0.2
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.115
  MBTHX64.dll                                         : 1.0.15.115
  MBWrp64.dll                                         : 1.0.0.180
  RCoInst64.dll                                       : 1.1.0.0
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.136
  RTCOMDLL.dll                                        : 2.0.0.136
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.160
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.141
  SFAPO64.dll                                         : 3.0.0.11
  SFCOM.dll                                           : 3.0.0.11
  SFCOM64.dll                                         : 3.0.0.11
  SFComm64.dll                                        : 2.0.0.13
  SFDAPO64.dll                                        : 2.0.0.13
  SFHAPO64.dll                                        : 2.0.0.13
  SFNHK64.dll                                         : 3.0.0.11
  SFProc64.dll                                        : 2.0.0.13
  SFSAPO64.dll                                        : 2.0.0.13
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 3.06
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.50
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6151
  RTKHDAUD.sys                                        : 5.10.0.6151
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.6.1
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.3
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.5
  RCoInst64XP.dll                                     : 1.0.9.9
  RTCOMDLL.dll                                        : 1.0.0.108
  RtkCoInstXP.dll                                     : 1.0.9.9
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6151
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.38
  RtHDVCpl.exe                                        : 1.0.0.545
  RtkAudioService.exe                                 : 1.0.0.27
  RtkNGUI.exe                                         : 1.0.0.52
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.52
  DarkSkinImages.dll                                  : 1.0.0.52
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.2
  DTSGFXAPONS.dll                                     : 1.0.0.2
  DTSLFXAPO.dll                                       : 1.0.0.2
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.32.66
  GrayJadeSkinImages.dll                              : 1.0.0.52
  LightSkinImages.dll                                 : 1.0.0.52
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.115
  MBWrp32.dll                                         : 1.0.0.180
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.135
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.156
  RtkApoApi.dll                                       : 1.0.0.21
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.1.0.0
  RtkGuiCompLib.dll                                   : 1.0.0.1
  RtkPgExt.dll                                        : 6.0.6000.138
  RtlCPAPI.dll                                        : 1.0.2.4
  SFAPO.dll                                           : 3.0.0.8
  SFCOM.dll                                           : 3.0.0.8
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  SFNHK.dll                                           : 3.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6151
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.38
  RAVCpl64.exe                                        : 1.0.0.545
  RtkAudioService64.exe                               : 1.0.0.27
  RtkNGUI64.exe                                       : 1.0.0.52
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.52
  DarkSkinImages64.dll                                : 1.0.0.52
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.2
  DTSGFXAPONS64.dll                                   : 1.0.0.2
  DTSLFXAPO64.dll                                     : 1.0.0.2
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.32.66
  GrayJadeSkinImages64.dll                            : 1.0.0.52
  LightSkinImages64.dll                               : 1.0.0.52
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxAudioRealtek2.dll                               : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.115
  MBTHX64.dll                                         : 1.0.15.115
  MBWrp64.dll                                         : 1.0.0.180
  RCoInst64.dll                                       : 1.1.0.0
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.135
  RTCOMDLL.dll                                        : 2.0.0.135
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.156
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtkGuiCompLib.dll                                   : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.138
  SFAPO64.dll                                         : 3.0.0.8
  SFCOM.dll                                           : 3.0.0.8
  SFCOM64.dll                                         : 3.0.0.8
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFNHK64.dll                                         : 3.0.0.8
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 3.01
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.49
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6132
  RTKHDAUD.sys                                        : 5.10.0.6132
  MicCal.exe                                          : 1.1.2.4
  RTHDCPL.exe                                         : 2.3.5.5
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.3
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.5
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.9.2
  RTCOMDLL.dll                                        : 1.0.0.108
  RtkCoInstXP.dll                                     : 1.0.9.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6132
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.26
  RtHDVCpl.exe                                        : 1.0.0.530
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.48
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.19
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.48
  DarkSkinImages.dll                                  : 1.0.0.48
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.32.66
  LightSkinImages.dll                                 : 1.0.0.48
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.112
  MBWrp32.dll                                         : 1.0.0.160
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.134
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.152
  RtkApoApi.dll                                       : 1.0.0.21
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.9.2
  RtkPgExt.dll                                        : 6.0.6000.130
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.2.0.0
  sluapo32.dll                                        : 1.8.34.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6132
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.26
  RAVCpl64.exe                                        : 1.0.0.530
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.48
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.19
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.48
  DarkSkinImages64.dll                                : 1.0.0.48
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.32.66
  LightSkinImages64.dll                               : 1.0.0.48
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.112
  MBTHX64.dll                                         : 1.0.15.112
  MBWrp64.dll                                         : 1.0.0.160
  RCoInst64.dll                                       : 1.0.9.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.134
  RTCOMDLL.dll                                        : 2.0.0.134
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.152
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.130
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.2.0.0
  sluapo64.dll                                        : 1.8.34.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6121
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.6
  RHDMIExt.dll                                        : 6.0.6000.127
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.151

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6121
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.6
  RHDMEx64.dll                                        : 6.0.6000.127
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.151

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6121
  Rtaupd.exe                                          : 2.8.0.3
  RHCoInstXP.dll                                      : 1.0.8.6

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6121
  Rtaupd64.exe                                        : 2.8.0.3
  RHCoInst64XP.dll                                    : 1.0.8.6

  Driver Setup Program                                : 2.99
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.48
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6101
  RTKHDAUD.sys                                        : 5.10.0.6101
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.4.9
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.3
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.8.6
  RTCOMDLL.dll                                        : 1.0.0.107
  RtkCoInstXP.dll                                     : 1.0.8.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6101
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.18
  RtHDVCpl.exe                                        : 1.0.0.513
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.39
  RtlUpd.exe                                          : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.39
  DarkSkinImages.dll                                  : 1.0.0.39
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.32.66
  LightSkinImages.dll                                 : 1.0.0.39
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.110
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.149
  RtkApoApi.dll                                       : 1.0.0.21
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.7
  RtkPgExt.dll                                        : 6.0.6000.122
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6101
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.18
  RAVCpl64.exe                                        : 1.0.0.513
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.39
  RtlUpd64.exe                                        : 2.8.0.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.39
  DarkSkinImages64.dll                                : 1.0.0.39
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.32.66
  LightSkinImages64.dll                               : 1.0.0.39
  MaxxAudioAPO20.dll                                  : 2.2.8.0
  MaxxAudioAPO30.dll                                  : 3.1.0.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MaxxAudioRealtek.dll                                : 1.0.0.0
  MaxxVolumeSDAPO.dll                                 : 3.1.0.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.110
  MBTHX64.dll                                         : 1.0.15.110
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.7
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.130
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.149
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.122
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.0.0.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.99
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.47
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6083
  RTKHDAUD.sys                                        : 5.10.0.6083
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.4.7
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.8.6
  RTCOMDLL.dll                                        : 1.0.0.107
  RtkCoInstXP.dll                                     : 1.0.8.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6083
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.13
  RtHDVCpl.exe                                        : 1.0.0.504
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.38
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.38
  DarkSkinImages.dll                                  : 1.0.0.38
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.30.65
  LightSkinImages.dll                                 : 1.0.0.38
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.145
  RtkApoApi.dll                                       : 1.0.0.21
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.6
  RtkPgExt.dll                                        : 6.0.6000.120
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6083
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.13
  RAVCpl64.exe                                        : 1.0.0.504
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.38
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.38
  DarkSkinImages64.dll                                : 1.0.0.38
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.30.65
  LightSkinImages64.dll                               : 1.0.0.38
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBTHX64.dll                                         : 1.0.15.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.130
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.145
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.120
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.97
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.46
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix BSOD issue under Windows 2000. (Issue happened from driver V6066).
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6077
  RTKHDAUD.sys                                        : 5.10.0.6077
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.4.6
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.1
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.8.6
  RTCOMDLL.dll                                        : 1.0.0.107
  RtkCoInstXP.dll                                     : 1.0.8.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6077
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.9
  RtHDVCpl.exe                                        : 1.0.0.501
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.35
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.35
  DarkSkinImages.dll                                  : 1.0.0.35
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.29.67
  LightSkinImages.dll                                 : 1.0.0.35
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.144
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.6
  RtkPgExt.dll                                        : 6.0.6000.119
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6077
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.9
  RAVCpl64.exe                                        : 1.0.0.501
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.35
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.35
  DarkSkinImages64.dll                                : 1.0.0.35
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.29.67
  LightSkinImages64.dll                               : 1.0.0.35
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBTHX64.dll                                         : 1.0.15.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.130
  RTCOMDLL.dll                                        : 2.0.0.130
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.144
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.119
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.97
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.45
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6069
  RTKHDAUD.sys                                        : 5.10.0.6069
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.4.2
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.8.6
  RTCOMDLL.dll                                        : 1.0.0.107
  RtkCoInstXP.dll                                     : 1.0.8.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6069
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.9
  RtHDVCpl.exe                                        : 1.0.0.500
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.31
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.31
  DarkSkinImages.dll                                  : 1.0.0.31
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.29.67
  LightSkinImages.dll                                 : 1.0.0.31
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.129
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.144
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.6
  RtkPgExt.dll                                        : 6.0.6000.119
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6069
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.9
  RAVCpl64.exe                                        : 1.0.0.500
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.31
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.31
  DarkSkinImages64.dll                                : 1.0.0.31
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.29.67
  LightSkinImages64.dll                               : 1.0.0.31
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBTHX64.dll                                         : 1.0.15.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.129
  RTCOMDLL.dll                                        : 2.0.0.129
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.144
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.119
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.96
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.44
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6066
  RTKHDAUD.sys                                        : 5.10.0.6066
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.4.0
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.8.6
  RTCOMDLL.dll                                        : 1.0.0.107
  RtkCoInstXP.dll                                     : 1.0.8.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6066
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.9
  RtHDVCpl.exe                                        : 1.0.0.499
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 1.0.0.29
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 1.0.0.29
  DarkSkinImages.dll                                  : 1.0.0.29
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.28.65
  LightSkinImages.dll                                 : 1.0.0.29
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.128
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.142
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.6
  RtkPgExt.dll                                        : 6.0.6000.119
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.12
  SFFXDAPO.dll                                        : 2.0.0.12
  SFFXHAPO.dll                                        : 2.0.0.12
  SFFXProc.dll                                        : 2.0.0.12
  SFFXSAPO.dll                                        : 2.0.0.12
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6066
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.9
  RAVCpl64.exe                                        : 1.0.0.499
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 1.0.0.29
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 1.0.0.29
  DarkSkinImages64.dll                                : 1.0.0.29
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.28.65
  LightSkinImages64.dll                               : 1.0.0.29
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.108
  MBTHX64.dll                                         : 1.0.15.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.128
  RTCOMDLL.dll                                        : 2.0.0.128
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.142
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.119
  SFComm64.dll                                        : 2.0.0.12
  SFDAPO64.dll                                        : 2.0.0.12
  SFHAPO64.dll                                        : 2.0.0.12
  SFProc64.dll                                        : 2.0.0.12
  SFSAPO64.dll                                        : 2.0.0.12
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.96
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.43
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6050
  RTKHDAUD.sys                                        : 5.10.0.6050
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.3.8
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.8.4
  RTCOMDLL.dll                                        : 1.0.0.106
  RtkCoInstXP.dll                                     : 1.0.8.4
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6050
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.489
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.25
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.25
  DarkSkinImages.dll                                  : 0.0.0.25
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.26.65
  LightSkinImages.dll                                 : 0.0.0.25
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.106
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.128
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.137
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.4
  RtkPgExt.dll                                        : 6.0.6000.116
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6050
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.489
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.25
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.25
  DarkSkinImages64.dll                                : 0.0.0.25
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.26.65
  LightSkinImages64.dll                               : 0.0.0.25
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.106
  MBTHX64.dll                                         : 1.0.15.106
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.4
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.128
  RTCOMDLL.dll                                        : 2.0.0.128
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.137
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.116
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.95
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.42
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6043
  RTKHDAUD.sys                                        : 5.10.0.6043
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.3.6
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.8.2
  RTCOMDLL.dll                                        : 1.0.0.105
  RtkCoInstXP.dll                                     : 1.0.8.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6043
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.484
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.24
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.11
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.24
  DarkSkinImages.dll                                  : 0.0.0.24
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.26.65
  LightSkinImages.dll                                 : 0.0.0.24
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.106
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.127
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.134
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.4
  RtkPgExt.dll                                        : 6.0.6000.114
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6043
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.484
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.24
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.11
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.24
  DarkSkinImages64.dll                                : 0.0.0.24
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.26.65
  LightSkinImages64.dll                               : 0.0.0.24
  MaxxAudioAPO20.dll                                  : 2.2.7.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.106
  MBTHX64.dll                                         : 1.0.15.106
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.4
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.127
  RTCOMDLL.dll                                        : 2.0.0.127
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.134
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.114
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.6034
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.8.2
  RHDMIExt.dll                                        : 6.0.6000.113
  RTEED32H.dll                                        : 6.1.6001.33
  RTEEG32H.dll                                        : 6.1.6001.33
  RTEEL32H.dll                                        : 6.1.6001.33
  RTEEP32H.dll                                        : 6.1.6001.33
  RtkHDMI.dll                                         : 11.0.6000.132

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.6034
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.8.2
  RHDMEx64.dll                                        : 6.0.6000.113
  RTEED64H.dll                                        : 6.1.6001.33
  RTEEG64H.dll                                        : 6.1.6001.33
  RTEEL64H.dll                                        : 6.1.6001.33
  RTEEP64H.dll                                        : 6.1.6001.33
  RtkHDM64.dll                                        : 11.0.6000.132

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.6034
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.8.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.6034
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.8.2

  Driver Setup Program                                : 2.94
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.41
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6029
  RTKHDAUD.sys                                        : 5.10.0.6029
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.3
  RTHDCPL.exe                                         : 2.3.3.2
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.1
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.38
  vncutil64.exe                                       : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.8.2
  RTCOMDLL.dll                                        : 1.0.0.104
  RtkCoInstXP.dll                                     : 1.0.8.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6029
  AERTSrv.exe                                         : 1.0.32.10
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.477
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.22
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.9
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.22
  DarkSkinImages.dll                                  : 0.0.0.22
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSGFXAPONS.dll                                     : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSSymmetryDLL.dll                                  : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.24.65
  LightSkinImages.dll                                 : 0.0.0.22
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.109
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.125
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.132
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.8.3
  RtkPgExt.dll                                        : 6.0.6000.113
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6029
  AERTSr64.exe                                        : 1.0.64.10
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.477
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.22
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.9
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.22
  DarkSkinImages64.dll                                : 0.0.0.22
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSGFXAPONS64.dll                                   : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSSymmetryDLL64.dll                                : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.24.65
  LightSkinImages64.dll                               : 0.0.0.22
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.109
  MBTHX64.dll                                         : 1.0.8.109
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.8.3
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.125
  RTCOMDLL.dll                                        : 2.0.0.125
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.132
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.113
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5992
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.109
  RtkHDMI.dll                                         : 11.0.6000.126

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5992
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.109
  RtkHDM64.dll                                        : 11.0.6000.126

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5992
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5992
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.92
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.40
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275, ALC680
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6013
  RTKHDAUD.sys                                        : 5.10.0.6013
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.2.8
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.7.9
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.9
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6013
  AERTSrv.exe                                         : 1.0.32.10
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.463
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.21
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.9
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.21
  DarkSkinImages.dll                                  : 0.0.0.21
  DTSBassEnhancementDLL.dll                           : 1.0.0.1
  DTSBoostDLL.dll                                     : 1.0.0.1
  DTSGainCompensatorDLL.dll                           : 1.0.0.1
  DTSGFXAPO.dll                                       : 1.0.0.1
  DTSLFXAPO.dll                                       : 1.0.0.1
  DTSLimiterDLL.dll                                   : 1.0.0.1
  DTSNeoPCDLL.dll                                     : 1.0.0.1
  DTSS2HeadphoneDLL.dll                               : 1.0.0.1
  DTSS2SpeakerDLL.dll                                 : 1.0.0.1
  DTSVoiceClarityDLL.dll                              : 1.0.0.1
  FMAPO.dll                                           : 42.5.23.65
  LightSkinImages.dll                                 : 0.0.0.21
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.103
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.124
  RTEED32A.dll                                        : 6.1.6001.33
  RTEEG32A.dll                                        : 6.1.6001.33
  RTEEL32A.dll                                        : 6.1.6001.33
  RTEEP32A.dll                                        : 6.1.6001.33
  RtkAPO.dll                                          : 11.0.6000.130
  RtkApoApi.dll                                       : 1.0.0.20
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.7.9
  RtkPgExt.dll                                        : 6.0.6000.112
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6013
  AERTSr64.exe                                        : 1.0.64.10
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.463
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.21
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.9
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.21
  DarkSkinImages64.dll                                : 0.0.0.21
  DTSBassEnhancementDLL64.dll                         : 1.0.0.1
  DTSBoostDLL64.dll                                   : 1.0.0.1
  DTSGainCompensatorDLL64.dll                         : 1.0.0.1
  DTSGFXAPO64.dll                                     : 1.0.0.1
  DTSLFXAPO64.dll                                     : 1.0.0.1
  DTSLimiterDLL64.dll                                 : 1.0.0.1
  DTSNeoPCDLL64.dll                                   : 1.0.0.1
  DTSS2HeadphoneDLL64.dll                             : 1.0.0.1
  DTSS2SpeakerDLL64.dll                               : 1.0.0.1
  DTSVoiceClarityDLL64.dll                            : 1.0.0.1
  FMAPO64.dll                                         : 42.6.23.65
  LightSkinImages64.dll                               : 0.0.0.21
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.15.103
  MBTHX64.dll                                         : 1.0.15.103
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.9
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.123
  RTCOMDLL.dll                                        : 2.0.0.123
  RTEED64A.dll                                        : 6.1.6001.33
  RTEEG64A.dll                                        : 6.1.6001.33
  RTEEL64A.dll                                        : 6.1.6001.33
  RTEEP64A.dll                                        : 6.1.6001.33
  RtkApi64.dll                                        : 1.0.0.20
  RtkAPO64.dll                                        : 11.0.6000.130
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.112
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5992
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.109
  RtkHDMI.dll                                         : 11.0.6000.126

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5992
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.109
  RtkHDM64.dll                                        : 11.0.6000.126

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5992
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5992
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.89
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.39
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.6000
  RTKHDAUD.sys                                        : 5.10.0.6000
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.2.5
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.7.8
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.8
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.6000
  AERTSrv.exe                                         : 1.0.32.10
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.456
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.17
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.9
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.17
  DarkSkinImages.dll                                  : 0.0.0.17
  FMAPO.dll                                           : 42.5.21.67
  LightSkinImages.dll                                 : 0.0.0.17
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.124
  RTEED32A.dll                                        : 6.1.6001.32
  RTEEG32A.dll                                        : 6.1.6001.32
  RTEEL32A.dll                                        : 6.1.6001.32
  RTEEP32A.dll                                        : 6.1.6001.32
  RtkAPO.dll                                          : 11.0.6000.129
  RtkApoApi.dll                                       : 1.0.0.19
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.7.8
  RtkPgExt.dll                                        : 6.0.6000.112
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.6000
  AERTSr64.exe                                        : 1.0.64.10
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.456
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.17
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.9
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.17
  DarkSkinImages64.dll                                : 0.0.0.17
  FMAPO64.dll                                         : 42.6.21.67
  LightSkinImages64.dll                               : 0.0.0.17
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.108
  MBTHX64.dll                                         : 1.0.8.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.8
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.123
  RTCOMDLL.dll                                        : 2.0.0.123
  RTEED64A.dll                                        : 6.1.6001.32
  RTEEG64A.dll                                        : 6.1.6001.32
  RTEEL64A.dll                                        : 6.1.6001.32
  RTEEP64A.dll                                        : 6.1.6001.32
  RtkApi64.dll                                        : 1.0.0.19
  RtkAPO64.dll                                        : 11.0.6000.129
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.112
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5992
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.1
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.109
  RtkHDMI.dll                                         : 11.0.6000.126

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5992
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.1
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.109
  RtkHDM64.dll                                        : 11.0.6000.126

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5992
  Rtaupd.exe                                          : 2.8.0.1
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5992
  Rtaupd64.exe                                        : 2.8.0.1
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.89
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.38
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Support graphic EQ feature.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5995
  RTKHDAUD.sys                                        : 5.10.0.5995
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.2.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.1
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.38
  vncutil.exe                                         : 1.0.0.38
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.7.6
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5995
  AERTSrv.exe                                         : 1.0.32.10
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.8
  RtHDVCpl.exe                                        : 1.0.0.453
  RtkAudioService.exe                                 : 1.0.0.24
  RtkNGUI.exe                                         : 0.0.0.15
  RtlUpd.exe                                          : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.38
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.18
  AERTACap.dll                                        : 2.0.32.9
  AERTARen.dll                                        : 1.0.32.9
  BlackSkinImages.dll                                 : 0.0.0.15
  DarkSkinImages.dll                                  : 0.0.0.15
  FMAPO.dll                                           : 42.5.21.66
  LightSkinImages.dll                                 : 0.0.0.15
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.108
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.124
  RTEED32A.dll                                        : 6.1.6001.32
  RTEEG32A.dll                                        : 6.1.6001.32
  RTEEL32A.dll                                        : 6.1.6001.32
  RTEEP32A.dll                                        : 6.1.6001.32
  RtkAPO.dll                                          : 11.0.6000.127
  RtkApoApi.dll                                       : 1.0.0.17
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.7.7
  RtkPgExt.dll                                        : 6.0.6000.109
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.9
  SFFXDAPO.dll                                        : 2.0.0.9
  SFFXHAPO.dll                                        : 2.0.0.9
  SFFXProc.dll                                        : 2.0.0.9
  SFFXSAPO.dll                                        : 2.0.0.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.24.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5995
  AERTSr64.exe                                        : 1.0.64.10
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.8
  RAVCpl64.exe                                        : 1.0.0.453
  RtkAudioService64.exe                               : 1.0.0.24
  RtkNGUI64.exe                                       : 0.0.0.15
  RtlUpd64.exe                                        : 2.8.0.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.38
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.18
  AERTAC64.dll                                        : 2.0.64.9
  AERTAR64.dll                                        : 1.0.64.9
  BlackSkinImages64.dll                               : 0.0.0.15
  DarkSkinImages64.dll                                : 0.0.0.15
  FMAPO64.dll                                         : 42.6.21.66
  LightSkinImages64.dll                               : 0.0.0.15
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.108
  MBTHX64.dll                                         : 1.0.8.108
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.7
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.123
  RTCOMDLL.dll                                        : 2.0.0.123
  RTEED64A.dll                                        : 6.1.6001.32
  RTEEG64A.dll                                        : 6.1.6001.32
  RTEEL64A.dll                                        : 6.1.6001.32
  RTEEP64A.dll                                        : 6.1.6001.32
  RtkApi64.dll                                        : 1.0.0.17
  RtkAPO64.dll                                        : 11.0.6000.127
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.109
  SFComm64.dll                                        : 2.0.0.9
  SFDAPO64.dll                                        : 2.0.0.9
  SFHAPO64.dll                                        : 2.0.0.9
  SFProc64.dll                                        : 2.0.0.9
  SFSAPO64.dll                                        : 2.0.0.9
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.24.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5945
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.100
  RtkHDMI.dll                                         : 11.0.6000.113

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5945
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.100
  RtkHDM64.dll                                        : 11.0.6000.113

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5945
  Rtaupd.exe                                          : 2.8.0.0
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5945
  Rtaupd64.exe                                        : 2.8.0.0
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.89
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.37
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC892, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5983
  RTKHDAUD.sys                                        : 5.10.0.5983
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.2.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.37
  vncutil.exe                                         : 1.0.0.37
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  OAO17Afx.sys                                        : 1.0.7.3
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.7.6
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5983
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.447
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.37
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.21.66
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.107
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.123
  RTEED32A.dll                                        : 6.1.6001.32
  RTEEG32A.dll                                        : 6.1.6001.32
  RTEEL32A.dll                                        : 6.1.6001.32
  RTEEP32A.dll                                        : 6.1.6001.32
  RtkAPO.dll                                          : 11.0.6000.125
  RtkApoApi.dll                                       : 1.0.0.15
  RtkCfg.dll                                          : 1.0.0.2
  RtkCoInst.dll                                       : 1.0.7.6
  RtkPgExt.dll                                        : 6.0.6000.108
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.8.22.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5983
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.447
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.37
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.21.66
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.107
  MBTHX64.dll                                         : 1.0.8.107
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.6
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.123
  RTCOMDLL.dll                                        : 2.0.0.123
  RTEED64A.dll                                        : 6.1.6001.32
  RTEEG64A.dll                                        : 6.1.6001.32
  RTEEL64A.dll                                        : 6.1.6001.32
  RTEEP64A.dll                                        : 6.1.6001.32
  RtkApi64.dll                                        : 1.0.0.15
  RtkAPO64.dll                                        : 11.0.6000.125
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.2
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.108
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.8.22.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  WavesGUILib.dll                                     : 1.2.3.4
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5945
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.100
  RtkHDMI.dll                                         : 11.0.6000.113

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5945
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.100
  RtkHDM64.dll                                        : 11.0.6000.113

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5945
  Rtaupd.exe                                          : 2.8.0.0
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5945
  Rtaupd64.exe                                        : 2.8.0.0
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.88
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.36
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.

        2.) Package :
            1. Fix some presentation string of Upgraded dialog in small VGA Mode .
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5969
  RTKHDAUD.sys                                        : 5.10.0.5969
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.2.1
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.33
  vncutil.exe                                         : 1.0.0.33
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.7.5
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.5
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5969
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.439
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.33
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.21.65
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.107
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.121
  RTEED32A.dll                                        : 6.1.6001.29
  RTEEG32A.dll                                        : 6.1.6001.29
  RTEEL32A.dll                                        : 6.1.6001.29
  RTEEP32A.dll                                        : 6.1.6001.29
  RtkAPO.dll                                          : 11.0.6000.121
  RtkApoApi.dll                                       : 1.0.0.13
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.7.5
  RtkPgExt.dll                                        : 6.0.6000.108
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5969
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.439
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.33
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.21.65
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.107
  MBTHX64.dll                                         : 1.0.8.107
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.5
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.121
  RTCOMDLL.dll                                        : 2.0.0.121
  RTEED64A.dll                                        : 6.1.6001.29
  RTEEG64A.dll                                        : 6.1.6001.29
  RTEEL64A.dll                                        : 6.1.6001.29
  RTEEP64A.dll                                        : 6.1.6001.29
  RtkApi64.dll                                        : 1.0.0.13
  RtkAPO64.dll                                        : 11.0.6000.121
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.108
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5945
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.100
  RtkHDMI.dll                                         : 11.0.6000.113

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5945
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.100
  RtkHDM64.dll                                        : 11.0.6000.113

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5945
  Rtaupd.exe                                          : 2.8.0.0
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5945
  Rtaupd64.exe                                        : 2.8.0.0
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.86
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.35
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.

        2.) Package :
            1. Fix some presentation of Spanish language .
            2. Add "Windows Server 2008 x64 R2" identification folder.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5953
  RTKHDAUD.sys                                        : 5.10.0.5953
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.1.8
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.32
  vncutil.exe                                         : 1.0.0.32
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.7.0
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.0
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5953
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.426
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.32
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.19.65
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.103
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED32A.dll                                        : 6.1.6001.29
  RTEEG32A.dll                                        : 6.1.6001.29
  RTEEL32A.dll                                        : 6.1.6001.29
  RTEEP32A.dll                                        : 6.1.6001.29
  RtkAPO.dll                                          : 11.0.6000.116
  RtkApoApi.dll                                       : 1.0.0.13
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.7.1
  RtkPgExt.dll                                        : 6.0.6000.103
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5953
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.426
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.32
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.19.65
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.22.0
  MBTHX32.dll                                         : 1.0.8.103
  MBTHX64.dll                                         : 1.0.8.103
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.1
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.120
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED64A.dll                                        : 6.1.6001.29
  RTEEG64A.dll                                        : 6.1.6001.29
  RTEEL64A.dll                                        : 6.1.6001.29
  RTEEP64A.dll                                        : 6.1.6001.29
  RtkApi64.dll                                        : 1.0.0.13
  RtkAPO64.dll                                        : 11.0.6000.116
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.103
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5945
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.7.0
  RHDMIExt.dll                                        : 6.0.6000.100
  RtkHDMI.dll                                         : 11.0.6000.113

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5945
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.7.0
  RHDMEx64.dll                                        : 6.0.6000.100
  RtkHDM64.dll                                        : 11.0.6000.113

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5945
  Rtaupd.exe                                          : 2.8.0.0
  RHCoInstXP.dll                                      : 1.0.7.0

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5945
  Rtaupd64.exe                                        : 2.8.0.0
  RHCoInst64XP.dll                                    : 1.0.7.0

  Driver Setup Program                                : 2.85
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.34
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC270, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5943
  RTKHDAUD.sys                                        : 5.10.0.5943
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.1.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.31
  vncutil.exe                                         : 1.0.0.31
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.7.0
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.7.0
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5943
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.422
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.31
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.18.67
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.102
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED32A.dll                                        : 6.1.6001.29
  RTEEG32A.dll                                        : 6.1.6001.29
  RTEEL32A.dll                                        : 6.1.6001.29
  RTEEP32A.dll                                        : 6.1.6001.29
  RtkAPO.dll                                          : 11.0.6000.113
  RtkApoApi.dll                                       : 1.0.0.13
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.7.0
  RtkPgExt.dll                                        : 6.0.6000.99
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5943
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.422
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.31
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.18.67
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.102
  MBTHX64.dll                                         : 1.0.8.102
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.7.0
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.120
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED64A.dll                                        : 6.1.6001.29
  RTEEG64A.dll                                        : 6.1.6001.29
  RTEEL64A.dll                                        : 6.1.6001.29
  RTEEP64A.dll                                        : 6.1.6001.29
  RtkApi64.dll                                        : 1.0.0.13
  RtkAPO64.dll                                        : 11.0.6000.113
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.99
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.84
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.33
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5936
  RTKHDAUD.sys                                        : 5.10.0.5936
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.1.2
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.29
  vncutil.exe                                         : 1.0.0.29
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.6.9
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.9
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5936
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.418
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.29
  RTSndMgr.cpl                                        : 1.0.0.17
  mbfilt32.sys                                        : 6.10.0.8
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.18.65
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.102
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED32A.dll                                        : 6.1.6001.29
  RTEEG32A.dll                                        : 6.1.6001.29
  RTEEL32A.dll                                        : 6.1.6001.29
  RTEEP32A.dll                                        : 6.1.6001.29
  RtkAPO.dll                                          : 11.0.6000.109
  RtkApoApi.dll                                       : 1.0.0.13
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.9
  RtkPgExt.dll                                        : 6.0.6000.96
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5936
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.418
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.29
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.18.65
  MaxxAudioAPO20.dll                                  : 2.2.6.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.102
  MBTHX64.dll                                         : 1.0.8.102
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.9
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.120
  RTCOMDLL.dll                                        : 2.0.0.120
  RTEED64A.dll                                        : 6.1.6001.29
  RTEEG64A.dll                                        : 6.1.6001.29
  RTEEL64A.dll                                        : 6.1.6001.29
  RTEEP64A.dll                                        : 6.1.6001.29
  RtkApi64.dll                                        : 1.0.0.13
  RtkAPO64.dll                                        : 11.0.6000.109
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.96
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.84
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.32
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5928
  RTKHDAUD.sys                                        : 5.10.0.5928
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.1.0
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.27
  vncutil.exe                                         : 1.0.0.27
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.6.5
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.5
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5928
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.6
  RtHDVCpl.exe                                        : 1.0.0.411
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.27
  mbfilt32.sys                                        : 6.10.0.8
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.17.68
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.19.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.119
  RTEED32A.dll                                        : 6.1.6001.29
  RTEEG32A.dll                                        : 6.1.6001.29
  RTEEL32A.dll                                        : 6.1.6001.29
  RTEEP32A.dll                                        : 6.1.6001.29
  RtkAPO.dll                                          : 11.0.6000.106
  RtkApoApi.dll                                       : 1.0.0.12
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.7
  RtkPgExt.dll                                        : 6.0.6000.93
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5928
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.6
  RAVCpl64.exe                                        : 1.0.0.411
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.27
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.17.68
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.0
  MBTHX64.dll                                         : 1.0.8.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.7
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.119
  RTCOMDLL.dll                                        : 2.0.0.119
  RTEED64A.dll                                        : 6.1.6001.29
  RTEEG64A.dll                                        : 6.1.6001.29
  RTEEL64A.dll                                        : 6.1.6001.29
  RTEEP64A.dll                                        : 6.1.6001.29
  RtkApi64.dll                                        : 1.0.0.12
  RtkAPO64.dll                                        : 11.0.6000.106
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.93
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.83
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.31
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix DTM KS position testing fail issue when turn on Microphone effect under Win7.
        2.) Package
            1. Reboot message in log file. ( WILL_REBOOT )
            2. Copy all of AP files to system.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5919
  RTKHDAUD.sys                                        : 5.10.0.5919
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.0.9
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.24
  vncutil.exe                                         : 1.0.0.25
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.4
  RCoInst64XP.dll                                     : 1.0.6.5
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.5
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5919
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.5
  RtHDVCpl.exe                                        : 1.0.0.401
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.25
  mbfilt32.sys                                        : 6.10.0.6
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.1.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBTHX32.dll                                         : 1.0.8.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkAPO.dll                                          : 11.0.6000.104
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.7
  RtkPgExt.dll                                        : 6.0.6000.89
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5919
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.5
  RAVCpl64.exe                                        : 1.0.0.401
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.24
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.8
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.1.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.19.0
  MBAPO64.dll                                         : 1.0.19.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.19.0
  MBTHX32.dll                                         : 1.0.8.0
  MBTHX64.dll                                         : 1.0.8.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.7
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.117
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.104
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.89
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.83
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.30
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670, ALC275
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix DTM testing issue under Win7.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5911
  RTKHDAUD.sys                                        : 5.10.0.5911
  MicCal.exe                                          : 1.1.2.2
  RTHDCPL.exe                                         : 2.3.0.7
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.8.0.0
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.4
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.6.5
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.5
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5911
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.5
  RtHDVCpl.exe                                        : 1.0.0.395
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  mbfilt32.sys                                        : 6.10.0.6
  RTSndMgr.cpl                                        : 1.0.0.17
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 42.5.1.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBTHX32.dll                                         : 1.0.8.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkAPO.dll                                          : 11.0.6000.101
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.5
  RtkPgExt.dll                                        : 6.0.6000.87
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.8
  SFFXDAPO.dll                                        : 2.0.0.8
  SFFXHAPO.dll                                        : 2.0.0.8
  SFFXProc.dll                                        : 2.0.0.8
  SFFXSAPO.dll                                        : 2.0.0.8
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5911
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.5
  RAVCpl64.exe                                        : 1.0.0.395
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.6
  RTSnMg64.cpl                                        : 1.0.0.17
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 42.6.1.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBTHX32.dll                                         : 1.0.8.0
  MBTHX64.dll                                         : 1.0.8.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.5
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.117
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.101
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.87
  SFComm64.dll                                        : 2.0.0.8
  SFDAPO64.dll                                        : 2.0.0.8
  SFHAPO64.dll                                        : 2.0.0.8
  SFProc64.dll                                        : 2.0.0.8
  SFSAPO64.dll                                        : 2.0.0.8
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.81
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.29
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC886, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5898
  RTKHDAUD.sys                                        : 5.10.0.5898
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.3.0.0
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.0
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.23
  vncutil64.exe                                       : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.3
  RCoInst64XP.dll                                     : 1.0.6.3
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.3
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5898
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.5
  RtHDVCpl.exe                                        : 1.0.0.386
  RtkAudioService.exe                                 : 1.0.0.24
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  mbfilt32.sys                                        : 6.10.0.6
  RTSndMgr.cpl                                        : 1.0.0.16
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.18.2
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBTHX32.dll                                         : 1.0.6.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkAPO.dll                                          : 11.0.6000.101
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.4
  RtkPgExt.dll                                        : 6.0.6000.84
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5898
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.5
  RAVCpl64.exe                                        : 1.0.0.386
  RtkAudioService64.exe                               : 1.0.0.24
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  mbfilt64.sys                                        : 6.10.0.6
  RTSnMg64.cpl                                        : 1.0.0.16
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.18.2
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBTHX32.dll                                         : 1.0.6.0
  MBTHX64.dll                                         : 1.0.6.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.4
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.117
  RTCOMDLL.dll                                        : 2.0.0.117
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.101
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.84
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5897
  RtkAudioSrvATI.exe                                  : 1.0.0.23
  RtkUpd.exe                                          : 2.8.0.0
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.4
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.101


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5897
  RtkAudioSrvATI64.exe                                : 1.0.0.23
  RtkUpd64.exe                                        : 2.8.0.0
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.4
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.101


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.81
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.28
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887,ALC670
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887,ALC670
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        2.) Package :
            1. Fix uninstallation driver issue under Windows x64 system .
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5888
  RTKHDAUD.sys                                        : 5.10.0.5888
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.9.7
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.8.0.0
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.23
  vncutil64.exe                                       : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.3
  RCoInst64XP.dll                                     : 1.0.6.2
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.6.2
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5888
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVBg.exe                                         : 1.0.0.5
  RtHDVCpl.exe                                        : 1.0.0.376
  RtkAudioService.exe                                 : 1.0.0.22
  RtlUpd.exe                                          : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.18.2
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.116
  RtkAPO.dll                                          : 11.0.6000.101
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.2
  RtkPgExt.dll                                        : 6.0.6000.82
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  RCORES.dat                                          : 1.0.0.5
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5888
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVBg64.exe                                         : 1.0.0.5
  RAVCpl64.exe                                        : 1.0.0.376
  RtkAudioService64.exe                               : 1.0.0.22
  RtlUpd64.exe                                        : 2.8.0.0
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.18.2
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.116
  RTCOMDLL.dll                                        : 2.0.0.116
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.101
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.82
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  RCORES64.dat                                        : 1.0.0.5
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5880
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.6.0
  RHDMIExt.dll                                        : 6.0.6000.82
  RtkHDMI.dll                                         : 11.0.6000.100


  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.6.0
  RHDMEx64.dll                                        : 6.0.6000.82
  RtkHDM64.dll                                        : 11.0.6000.100


  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5880
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1
  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5880
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.80
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.27
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix GUI issue which can't launch Windows MediaPlayer under Win7 OS.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5874
  RTKHDAUD.sys                                        : 5.10.0.5874
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.9.2
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.4
  RtlUpd.exe                                          : 2.7.1.4
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.5.9
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.5.9
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5874
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.366
  RtkAudioService.exe                                 : 1.0.0.21
  RtlUpd.exe                                          : 2.7.1.4
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkAPO.dll                                          : 11.0.6000.100
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.6.0
  RtkPgExt.dll                                        : 6.0.6000.82
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.2.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.8.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5874
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.366
  RtkAudioService64.exe                               : 1.0.0.21
  RtlUpd64.exe                                        : 2.7.1.4
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.6.0
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.113
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.100
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.82
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.2.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.8.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5857
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.4.9
  RHDMIExt.dll                                        : 6.0.6000.79
  RtkHDMI.dll                                         : 11.0.6000.99

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.79
  RtkHDM64.dll                                        : 11.0.6000.99

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5857
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.77
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.26
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Update SRS components.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5864
  RTKHDAUD.sys                                        : 5.10.0.5864
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.9.0
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.3
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.5.6
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.5.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5864
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.356
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkAPO.dll                                          : 11.0.6000.99
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.8
  RtkPgExt.dll                                        : 6.0.6000.79
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.4.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5864
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.356
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.5.8
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.113
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.99
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.79
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.4.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5857
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.4.9
  RHDMIExt.dll                                        : 6.0.6000.79
  RtkHDMI.dll                                         : 11.0.6000.99

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.79
  RtkHDM64.dll                                        : 11.0.6000.99

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5857
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.76
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.25
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista/Windows 7 WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Windows 7 WHQL Driver.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5859
  RTKHDAUD.sys                                        : 5.10.0.5859
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.9.0
  RtkAudioService.exe                                 : 1.0.0.19
  RtkAudioService64.exe                               : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.7.1.3
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.23
  vncutil64.exe                                       : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.3
  RCoInst64XP.dll                                     : 1.0.5.6
  RTCOMDLL.dll                                        : 1.0.0.103
  RtkCoInstXP.dll                                     : 1.0.5.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista/Win7 driver : --------------------------------------------------------
  Vista/Win7 driver for x86
  RTKVHDA.sys                                         : 6.0.1.5859
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.353
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.9.0
  MBPPCn32.dll                                        : 1.0.0.110
  MBppld32.dll                                        : 1.0.9.0
  MBWrp32.dll                                         : 1.0.0.110
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkAPO.dll                                          : 11.0.6000.99
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.8
  RtkPgExt.dll                                        : 6.0.6000.79
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.0.4.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.3.4.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista/Win7 driver for x64
  RTKVHD64.sys                                        : 6.0.1.5859
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.353
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.9.0
  MBAPO64.dll                                         : 1.0.9.0
  MBPPCn64.dll                                        : 1.0.0.110
  MBppld64.dll                                        : 1.0.9.0
  MBWrp64.dll                                         : 1.0.0.110
  RCoInst64.dll                                       : 1.0.5.8
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.113
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.99
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.79
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.0.4.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.3.4.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista/Win7 x86:
  RtHDMIV.sys                                         : 6.0.1.5857
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.4.9
  RHDMIExt.dll                                        : 6.0.6000.79
  RtkHDMI.dll                                         : 11.0.6000.99

  Vista/Win7 x64:
  RtHDMIVX.sys                                        : 6.0.1.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.79
  RtkHDM64.dll                                        : 11.0.6000.99

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5857
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5857
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.76
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.24
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5854
  RTKHDAUD.sys                                        : 5.10.0.5854
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.8.8
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.3
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.3
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.5.6
  RTCOMDLL.dll                                        : 1.0.0.102
  RtkCoInstXP.dll                                     : 1.0.5.6
  RtlCPAPI.dll                                        : 1.0.2.3
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5854
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.352
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkAPO.dll                                          : 11.0.6000.99
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.7
  RtkPgExt.dll                                        : 6.0.6000.79
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.0.4.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.3.4.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5854
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.352
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.5.7
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.113
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.99
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.79
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.0.4.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.3.4.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5832
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.4.9
  RHDMIExt.dll                                        : 6.0.6000.75
  RtkHDMI.dll                                         : 11.0.6000.95

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5832
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.75
  RtkHDM64.dll                                        : 11.0.6000.95

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5832
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5832
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.76
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.23
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix DTM 1.4 lullaby test & wave pull mode test issue.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5845
  RTKHDAUD.sys                                        : 5.10.0.5845
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.8.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.3
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.3
  RCoInst64XP.dll                                     : 1.0.5.3
  RTCOMDLL.dll                                        : 1.0.0.102
  RtkCoInstXP.dll                                     : 1.0.5.3
  RtlCPAPI.dll                                        : 1.0.2.3
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5845
  AERTSrv.exe                                         : 1.0.32.9
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.345
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.8
  AERTARen.dll                                        : 1.0.32.8
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkAPO.dll                                          : 11.0.6000.98
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.5
  RtkPgExt.dll                                        : 6.0.6000.78
  RtlCPAPI.dll                                        : 1.0.2.4
  SFFXComm.dll                                        : 2.0.0.6
  SFFXDAPO.dll                                        : 2.0.0.6
  SFFXHAPO.dll                                        : 2.0.0.6
  SFFXProc.dll                                        : 2.0.0.6
  SFFXSAPO.dll                                        : 2.0.0.6
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.0.4.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.3.4.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5845
  AERTSr64.exe                                        : 1.0.64.9
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.345
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.8
  AERTAR64.dll                                        : 1.0.64.8
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.5.5
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.113
  RTCOMDLL.dll                                        : 2.0.0.113
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.98
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.4
  RtlCPAPI64.dll                                      : 1.0.2.4
  RtPgEx64.dll                                        : 6.0.6000.78
  SFComm64.dll                                        : 2.0.0.6
  SFDAPO64.dll                                        : 2.0.0.6
  SFHAPO64.dll                                        : 2.0.0.6
  SFProc64.dll                                        : 2.0.0.6
  SFSAPO64.dll                                        : 2.0.0.6
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.0.4.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.3.4.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5832
  RtkUpd.exe                                          : 2.7.1.3
  RH3DAA32.dll                                        : 6.0.6001.18
  RH3DHT32.dll                                        : 6.0.6001.18
  RHCoInst.dll                                        : 1.0.4.9
  RHDMIExt.dll                                        : 6.0.6000.75
  RtkHDMI.dll                                         : 11.0.6000.95

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5832
  RtkUpd64.exe                                        : 2.7.1.3
  RH3DAA64.dll                                        : 6.0.6001.18
  RH3DHT64.dll                                        : 6.0.6001.18
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.75
  RtkHDM64.dll                                        : 11.0.6000.95

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5832
  RtkUpd.exe                                          : 2.7.1.3
  RHCoInstXP.dll                                      : 1.0.5.1

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5832
  RtkUpd64.exe                                        : 2.7.1.3
  RHCoInst64XP.dll                                    : 1.0.5.1

  Driver Setup Program                                : 2.75
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.22
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5832
  RTKHDAUD.sys                                        : 5.10.0.5832
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.7.8
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.3
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.2
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.5.0
  RTCOMDLL.dll                                        : 1.0.0.101
  RtkCoInstXP.dll                                     : 1.0.5.0
  RtlCPAPI.dll                                        : 1.0.2.2
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5832
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.334
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.7
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RP3DAA32.dll                                        : 6.0.6001.18
  RP3DHT32.dll                                        : 6.0.6001.18
  RTCOMDLL.dll                                        : 2.0.0.111
  RtkAPO.dll                                          : 11.0.6000.95
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.2
  RtkPgExt.dll                                        : 6.0.6000.75
  RtlCPAPI.dll                                        : 1.0.2.2
  SFCPStr.dll                                         : 1.1.0.3
  SFFXComm.dll                                        : 1.1.0.3
  SFFXCP.dll                                          : 1.1.0.3
  SFFXLAPO.dll                                        : 1.1.0.3
  SFFXProc.dll                                        : 1.1.0.3
  SFFXSAPO.dll                                        : 1.1.0.3
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.0.4.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.3.4.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5832
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.334
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.3
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.7
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.5.2
  RP3DAA64.dll                                        : 6.0.6001.18
  RP3DHT64.dll                                        : 6.0.6001.18
  RtCOM64.dll                                         : 2.0.0.111
  RTCOMDLL.dll                                        : 2.0.0.111
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.95
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.2
  RtlCPAPI64.dll                                      : 1.0.2.2
  RtPgEx64.dll                                        : 6.0.6000.75
  SFComm64.dll                                        : 1.1.0.3
  SFCP64.dll                                          : 1.1.0.3
  SFCPStr.dll                                         : 1.1.0.3
  SFLAPO64.dll                                        : 1.1.0.3
  SFProc64.dll                                        : 1.1.0.3
  SFSAPO64.dll                                        : 1.1.0.3
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.0.4.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.3.4.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5796
  RtkUpd.exe                                          : 2.7.1.2
  AHPCEE32.dll                                        : 6.0.6001.17
  RHCoInst.dll                                        : 1.0.4.4
  RHDMIExt.dll                                        : 6.0.6000.69
  RtkHDMI.dll                                         : 11.0.6000.88

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5796
  RtkUpd64.exe                                        : 2.7.1.2
  AHPCEE64.dll                                        : 6.0.6001.17
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.69
  RtkHDM64.dll                                        : 11.0.6000.88

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5796
  RtkUpd.exe                                          : 2.7.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5796
  RtkUpd64.exe                                        : 2.7.1.2

  Driver Setup Program                                : 2.75
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.21
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Support ALC275.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5821
  RTKHDAUD.sys                                        : 5.10.0.5821
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.7.5
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.2
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.5.0
  RTCOMDLL.dll                                        : 1.0.0.100
  RtkCoInstXP.dll                                     : 1.0.5.0
  RtlCPAPI.dll                                        : 1.0.2.2
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5821
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.323
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.7
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.110
  RtkAPO.dll                                          : 11.0.6000.90
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.0
  RtkPgExt.dll                                        : 6.0.6000.70
  RtlCPAPI.dll                                        : 1.0.2.2
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.3.0
  slmaxv32.dll                                        : 1.0.4.0
  sltshd32.dll                                        : 1.1.1.0
  sluapo32.dll                                        : 1.3.4.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5821
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.323
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.7
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.5.0
  RtCOM64.dll                                         : 2.0.0.110
  RTCOMDLL.dll                                        : 2.0.0.110
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.90
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.2
  RtlCPAPI64.dll                                      : 1.0.2.2
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.70
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.3.0
  slmaxv64.dll                                        : 1.0.4.0
  sltshd64.dll                                        : 1.1.1.0
  sluapo64.dll                                        : 1.3.4.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5796
  RtkUpd.exe                                          : 2.7.1.2
  AHPCEE32.dll                                        : 6.0.6001.17
  RHCoInst.dll                                        : 1.0.4.4
  RHDMIExt.dll                                        : 6.0.6000.69
  RtkHDMI.dll                                         : 11.0.6000.88

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5796
  RtkUpd64.exe                                        : 2.7.1.2
  AHPCEE64.dll                                        : 6.0.6001.17
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.69
  RtkHDM64.dll                                        : 11.0.6000.88

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5796
  RtkUpd.exe                                          : 2.7.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5796
  RtkUpd64.exe                                        : 2.7.1.2

  Driver Setup Program                                : 2.74
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.20
    Realtek HD Audio Driver support all of Realtek HD Audio Codec .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Windows Server 2003, Vista, Windows Server 2008, Windows7 - x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.

        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5817
  RTKHDAUD.sys                                        : 5.10.0.5817
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.7.4
  RtkAudioService64.exe                               : 1.0.0.19
  RtkAudioService.exe                                 : 1.0.0.19
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.2
  RCoInst64XP.dll                                     : 1.0.5.0
  RTCOMDLL.dll                                        : 1.0.0.99
  RtkCoInstXP.dll                                     : 1.0.5.0
  RtlCPAPI.dll                                        : 1.0.2.2
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5817
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.319
  RtkAudioService.exe                                 : 1.0.0.19
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.5
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.109
  RtkAPO.dll                                          : 11.0.6000.90
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.5.0
  RtkPgExt.dll                                        : 6.0.6000.70
  RtlCPAPI.dll                                        : 1.0.2.2
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5817
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.319
  RtkAudioService64.exe                               : 1.0.0.19
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.5.0
  RtCOM64.dll                                         : 2.0.0.109
  RTCOMDLL.dll                                        : 2.0.0.109
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.90
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.2
  RtlCPAPI64.dll                                      : 1.0.2.2
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.70
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5796
  RtkUpd.exe                                          : 2.7.1.2
  AHPCEE32.dll                                        : 6.0.6001.17
  RHCoInst.dll                                        : 1.0.4.4
  RHDMIExt.dll                                        : 6.0.6000.69
  RtkHDMI.dll                                         : 11.0.6000.88

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5796
  RtkUpd64.exe                                        : 2.7.1.2
  AHPCEE64.dll                                        : 6.0.6001.17
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.69
  RtkHDM64.dll                                        : 11.0.6000.88

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5796
  RtkUpd.exe                                          : 2.7.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5796
  RtkUpd64.exe                                        : 2.7.1.2

  Driver Setup Program                                : 2.74
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.19
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista, Windows7 x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        2.) Package :
            1. Fix upgraded warning dialog for Small VGA mode .
            2. Add failed run installation by count .
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5809
  RTKHDAUD.sys                                        : 5.10.0.5809
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.1
  RTHDCPL.exe                                         : 2.2.7.1
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RCoInst64XP.dll                                     : 1.0.4.9
  RTCOMDLL.dll                                        : 1.0.0.99
  RtkCoInstXP.dll                                     : 1.0.4.9
  RtlCPAPI.dll                                        : 1.0.2.2
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5809
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.314
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.109
  RtkAPO.dll                                          : 11.0.6000.89
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.9
  RtkPgExt.dll                                        : 6.0.6000.70
  RtlCPAPI.dll                                        : 1.0.2.2
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5809
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.314
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.4.9
  RtCOM64.dll                                         : 2.0.0.109
  RTCOMDLL.dll                                        : 2.0.0.109
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.89
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.2
  RtlCPAPI64.dll                                      : 1.0.2.2
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.70
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5796
  RtkUpd.exe                                          : 2.7.1.2
  AHPCEE32.dll                                        : 6.0.6001.17
  RHCoInst.dll                                        : 1.0.4.4
  RHDMIExt.dll                                        : 6.0.6000.69
  RtkHDMI.dll                                         : 11.0.6000.88

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5796
  RtkUpd64.exe                                        : 2.7.1.2
  AHPCEE64.dll                                        : 6.0.6001.17
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.69
  RtkHDM64.dll                                        : 11.0.6000.88

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5796
  RtkUpd.exe                                          : 2.7.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5796
  RtkUpd64.exe                                        : 2.7.1.2

  Driver Setup Program                                : 2.73
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.18
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista, Windows7 x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        2.) Package :
            1. Support driver folder of Windows Server 2008 in package .
            2. Disable Status Dialog when small VGA Mode enabled .
            3. Fix CreativeUp folder disappear issue .
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5804
  RTKHDAUD.sys                                        : 5.10.0.5804
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.6.9
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.4
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.8
  RTCOMDLL.dll                                        : 1.0.0.98
  RtkCoInstXP.dll                                     : 1.0.4.8
  RtlCPAPI.dll                                        : 1.0.2.1
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5804
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.311
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.108
  RtkAPO.dll                                          : 11.0.6000.89
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.8
  RtkPgExt.dll                                        : 6.0.6000.69
  RtlCPAPI.dll                                        : 1.0.2.1
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5804
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.311
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.4.8
  RtCOM64.dll                                         : 2.0.0.108
  RTCOMDLL.dll                                        : 2.0.0.108
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.89
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.69
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5796
  RtkUpd.exe                                          : 2.7.1.2
  AHPCEE32.dll                                        : 6.0.6001.17
  RHCoInst.dll                                        : 1.0.4.4
  RHDMIExt.dll                                        : 6.0.6000.69
  RtkHDMI.dll                                         : 11.0.6000.88

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5796
  RtkUpd64.exe                                        : 2.7.1.2
  AHPCEE64.dll                                        : 6.0.6001.17
  RHCoInst64.dll                                      : 1.0.4.4
  RHDMEx64.dll                                        : 6.0.6000.69
  RtkHDM64.dll                                        : 11.0.6000.88

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5796
  RtkUpd.exe                                          : 2.7.1.2

  XP/2K x64:
  RtkHDMIX.sys                                        : 5.10.0.5796
  RtkUpd64.exe                                        : 2.7.1.2

  Driver Setup Program                                : 2.72
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.17
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista, Windows7 x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5794
  RTKHDAUD.sys                                        : 5.10.0.5794
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.6.5
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.8
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.8
  RtlCPAPI.dll                                        : 1.0.2.1
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5794
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.306
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkAPO.dll                                          : 11.0.6000.88
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.8
  RtkPgExt.dll                                        : 6.0.6000.69
  RtlCPAPI.dll                                        : 1.0.2.1
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5794
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.306
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.4.8
  RtCOM64.dll                                         : 2.0.0.106
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.88
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.69
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5766
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.66
  RtkHDMI.dll                                         : 11.0.6000.85

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5766
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.66
  RtkHDM64.dll                                        : 11.0.6000.85

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5766
  RtkUpd.exe                                          : 2.7.1.1

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5766
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.70
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.16
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista, Windows7 x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Update directsound acceleration engine for XP driver.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5791
  RTKHDAUD.sys                                        : 5.10.0.5791
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.6.3
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.8
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.8
  RtlCPAPI.dll                                        : 1.0.2.1
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5791
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.304
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.15
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.14.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkAPO.dll                                          : 11.0.6000.88
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.8
  RtkPgExt.dll                                        : 6.0.6000.69
  RtlCPAPI.dll                                        : 1.0.2.1
  RTPCEE32.dll                                        : 6.0.6001.17
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5791
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.304
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.15
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.14.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.4.8
  RtCOM64.dll                                         : 2.0.0.106
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.88
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RTPCEE64.dll                                        : 6.0.6001.17
  RtPgEx64.dll                                        : 6.0.6000.69
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5766
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.66
  RtkHDMI.dll                                         : 11.0.6000.85

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5766
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.66
  RtkHDM64.dll                                        : 11.0.6000.85

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5766
  RtkUpd.exe                                          : 2.7.1.1

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5766
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.70
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.15
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Change Creative components for the certain customers.
        2.) Package :
            1. Change Japanese language on finish Dialog of installation .
            2. Fix DCC uninstalled issue. Both MSI and GUID uninstallation procedure supported .
            3. Fix uninstall problem in Windows 7 . The DIFxAPI DLL file supported in Windows 7 .
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5783
  RTKHDAUD.sys                                        : 5.10.0.5783
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.6.2
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.2
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt.sys                                         : 5.10.0.4112
  Monft64.sys                                         : 5.10.0.4115
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFt64.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.8
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.8
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5783
  AERTSrv.exe                                         : 1.0.32.8
  APOPCH.exe                                          : 1.0.0.0
  RtHDVCpl.exe                                        : 1.0.0.300
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  MBAPO32.dll                                         : 1.0.0.630
  MBPPCn32.dll                                        : 1.0.0.80
  MBppld32.dll                                        : 1.0.0.630
  MBWrp32.dll                                         : 1.0.0.80
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkAPO.dll                                          : 11.0.6000.87
  RtkApoApi.dll                                       : 1.0.0.10
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.8
  RtkPgExt.dll                                        : 6.0.6000.67
  RtlCPAPI.dll                                        : 1.0.2.1
  RTPCEE32.dll                                        : 6.0.6001.14
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5783
  AERTSr64.exe                                        : 1.0.64.8
  APOPCH.exe                                          : 1.0.0.0
  RAVCpl64.exe                                        : 1.0.0.300
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.2
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MBAPO32.dll                                         : 1.0.0.630
  MBAPO64.dll                                         : 1.0.0.630
  MBPPCn64.dll                                        : 1.0.0.80
  MBppld64.dll                                        : 1.0.0.630
  MBWrp64.dll                                         : 1.0.0.80
  RCoInst64.dll                                       : 1.0.4.8
  RtCOM64.dll                                         : 2.0.0.106
  RTCOMDLL.dll                                        : 2.0.0.106
  RtkApi64.dll                                        : 1.0.0.10
  RtkAPO64.dll                                        : 11.0.6000.87
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RTPCEE64.dll                                        : 6.0.6001.14
  RtPgEx64.dll                                        : 6.0.6000.67
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5766
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.66
  RtkHDMI.dll                                         : 11.0.6000.85

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5766
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.66
  RtkHDM64.dll                                        : 11.0.6000.85

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5766
  RtkUpd.exe                                          : 2.7.1.1

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5766
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.70
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.14
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Change EAPD control method for the certain codecs.
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5772
  RTKHDAUD.sys                                        : 5.10.0.5772
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.9
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RCoInst64XP.dll                                     : 1.0.4.4
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.4
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5772
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.291
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkAPO.dll                                          : 11.0.6000.85
  RtkApoApi.dll                                       : 1.0.0.9
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.4
  RtkPgExt.dll                                        : 6.0.6000.66
  RtlCPAPI.dll                                        : 1.0.2.1
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5772
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.291
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.4
  RtCOM64.dll                                         : 2.0.0.105
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkApi64.dll                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.6000.85
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RtPgEx64.dll                                        : 6.0.6000.66
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5766
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.66
  RtkHDMI.dll                                         : 11.0.6000.85

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5766
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.66
  RtkHDM64.dll                                        : 11.0.6000.85

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5766
  RtkUpd.exe                                          : 2.7.1.1

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5766
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.69
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.13
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5767
  RTKHDAUD.sys                                        : 5.10.0.5767
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.8
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.3
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.3
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5767
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.288
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkAPO.dll                                          : 11.0.6000.85
  RtkApoApi.dll                                       : 1.0.0.9
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.3
  RtkPgExt.dll                                        : 6.0.6000.66
  RtlCPAPI.dll                                        : 1.0.2.1
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5767
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.288
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.3
  RtCOM64.dll                                         : 2.0.0.105
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkApi64.dll                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.6000.85
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RtPgEx64.dll                                        : 6.0.6000.66
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5766
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.66
  RtkHDMI.dll                                         : 11.0.6000.85

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5766
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.66
  RtkHDM64.dll                                        : 11.0.6000.85

  XP/2K x86:
  RtkHDMI.sys                                         : 5.10.0.5766
  RtkUpd.exe                                          : 2.7.1.1

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5766
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.69
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.12
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.    
            2. Support encryption feature for ALC670.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5764
  RTKHDAUD.sys                                        : 5.10.0.5764
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.6
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.23
  vncutil.exe                                         : 1.0.0.23
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RCoInst64XP.dll                                     : 1.0.4.3
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.3
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5764
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.286
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkAPO.dll                                          : 11.0.6000.85
  RtkApoApi.dll                                       : 1.0.0.9
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.3
  RtkPgExt.dll                                        : 6.0.6000.66
  RtlCPAPI.dll                                        : 1.0.2.1
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5764
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.286
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.3
  RtCOM64.dll                                         : 2.0.0.105
  RTCOMDLL.dll                                        : 2.0.0.105
  RtkApi64.dll                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.6000.85
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RtPgEx64.dll                                        : 6.0.6000.66
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5735
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.64
  RtkHDMI.dll                                         : 11.0.6000.80


  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5735
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.64
  RtkHDM64.dll                                        : 11.0.6000.80

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5735
  RtkUpd.exe                                          : 2.7.1.1
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5735
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.69
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.11
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.    
            2. Add DisplayVersion registry key in INF files.        

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5755
  RTKHDAUD.sys                                        : 5.10.0.5755
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.5
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.22
  vncutil.exe                                         : 1.0.0.22
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RCoInst64XP.dll                                     : 1.0.4.1
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.1
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5755
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.281
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.23
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.103
  RtkAPO.dll                                          : 11.0.6000.81
  RtkApoApi.dll                                       : 1.0.0.9
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.1
  RtkPgExt.dll                                        : 6.0.6000.65
  RtlCPAPI.dll                                        : 1.0.2.1
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5755
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.281
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.23
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.1
  RtCOM64.dll                                         : 2.0.0.103
  RTCOMDLL.dll                                        : 2.0.0.103
  RtkApi64.dll                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.6000.81
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RtPgEx64.dll                                        : 6.0.6000.65
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5735
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.64
  RtkHDMI.dll                                         : 11.0.6000.80


  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5735
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.64
  RtkHDM64.dll                                        : 11.0.6000.80

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5735
  RtkUpd.exe                                          : 2.7.1.1
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5735
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.69
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.10
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC665, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.    
            2. Support ALC665.        
        

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5745
  RTKHDAUD.sys                                        : 5.10.0.5745
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.2
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.22
  vncutil.exe                                         : 1.0.0.22
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.4.1
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.4.1
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5745
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.273
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil.exe                                         : 1.0.0.22
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.0
  RTCOMDLL.dll                                        : 2.0.0.103
  RtkAPO.dll                                          : 11.0.6000.81
  RtkApoApi.dll                                       : 1.0.0.9
  RtkCfg.dll                                          : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.1
  RtkPgExt.dll                                        : 6.0.6000.65
  RtlCPAPI.dll                                        : 1.0.2.1
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5745
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.273
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.2
  vncutil64.exe                                       : 1.0.0.22
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.4.1
  RtCOM64.dll                                         : 2.0.0.103
  RTCOMDLL.dll                                        : 2.0.0.103
  RtkApi64.dll                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.6000.81
  RtkCfg.dll                                          : 1.0.0.1
  RtkCfg64.dll                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.4.0
  RtlCPAPI.dll                                        : 1.0.2.1
  RtlCPAPI64.dll                                      : 1.0.2.1
  RtPgEx64.dll                                        : 6.0.6000.65
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5735
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.64
  RtkHDMI.dll                                         : 11.0.6000.80


  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5735
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.64
  RtkHDM64.dll                                        : 11.0.6000.80

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5735
  RtkUpd.exe                                          : 2.7.1.1
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5735
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.69
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.09
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.            
        

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5735
  RTKHDAUD.sys                                        : 5.10.0.5735
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.5.1
  RtkAudioService.exe                                 : 1.0.0.16
  RtkAudioService64.exe                               : 1.0.0.17
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.7.1.1
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil.exe                                         : 1.0.0.22
  vncutil64.exe                                       : 1.0.0.22
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFilt64.sys                                       : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monfilt64.sys                                       : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RCoInst64XP.dll                                     : 1.0.3.9
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.3.9
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5735
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.264
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  RTSndMgr.cpl                                        : 1.0.0.13
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.80
  RtkApoApi.dll                                       : 1.0.0.8
  RtkCoInst.dll                                       : 1.0.3.9
  RtkPgExt.dll                                        : 6.0.6000.64
  RtlCPAPI.dll                                        : 1.0.1.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5735
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.264
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil64.exe                                       : 1.0.0.22
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.13
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.2.2.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.9
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.8
  RtkAPO64.dll                                        : 11.0.6000.80
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.64
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5735
  RtkUpd.exe                                          : 2.7.1.1
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.64
  RtkHDMI.dll                                         : 11.0.6000.80


  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5735
  RtkUpd64.exe                                        : 2.7.1.1
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.64
  RtkHDM64.dll                                        : 11.0.6000.80

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5735
  RtkUpd.exe                                          : 2.7.1.1
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5735
  RtkUpd64.exe                                        : 2.7.1.1

  Driver Setup Program                                : 2.67
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013

//=================
Driver Package R2.08
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Support Andrea microphone effect mixer type GUI.
        2.) Package:
            1. Change setup program install location to meet the requirements of OEM Ready Certification Tool 1.1.0.1101


     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5730
  RTKHDAUD.sys                                        : 5.10.0.5730
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.4.9
  RtkAudioService64.exe                               : 1.0.0.17
  RtkAudioService.exe                                 : 1.0.0.16
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  vncutil64.exe                                       : 1.0.0.22
  vncutil.exe                                         : 1.0.0.22
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RCoInst64XP.dll                                     : 1.0.3.8
  RTCOMDLL.dll                                        : 1.0.0.97
  RtkCoInstXP.dll                                     : 1.0.3.8
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5730
  AERTSrv.exe                                         : 1.0.32.8
  RtHDVCpl.exe                                        : 1.0.0.257
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  RTSndMgr.cpl                                        : 1.0.0.10
  AERTACap.dll                                        : 2.0.32.1
  AERTARen.dll                                        : 1.0.32.7
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 0.0.12.1
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.79
  RtkApoApi.dll                                       : 1.0.0.8
  RtkCoInst.dll                                       : 1.0.3.8
  RtkPgExt.dll                                        : 6.0.6000.64
  RtlCPAPI.dll                                        : 1.0.1.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5730
  AERTSr64.exe                                        : 1.0.64.8
  RAVCpl64.exe                                        : 1.0.0.257
  RtkAudioService64.exe                               : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil64.exe                                       : 1.0.0.22
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.10
  AERTAC64.dll                                        : 2.0.64.1
  AERTAR64.dll                                        : 1.0.64.7
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 0.0.12.1
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.8
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.8
  RtkAPO64.dll                                        : 11.0.6000.79
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.64
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.67
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.07
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
    
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5717
  RTKHDAUD.sys                                        : 5.10.0.5717
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.4.8
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd.exe                                          : 2.7.1.1
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  AMBFilt.sys                                         : 5.10.0.4240
  AMBFilt64.sys                                       : 5.10.0.4240
  Monfilt.sys                                         : 5.10.0.4112
  Monfilt64.sys                                       : 5.10.0.4115
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5717
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.251
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  RTSndMgr.cpl                                        : 1.0.0.10
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.78
  RtkApoApi.dll                                       : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.3.7
  RtkPgExt.dll                                        : 6.0.6000.61
  RtlCPAPI.dll                                        : 1.0.1.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5717
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.251
  RtkAudioService.exe                                 : 1.0.0.17
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.10
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.7
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.6
  RtkAPO64.dll                                        : 11.0.6000.78
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.61
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.64
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.06
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
    
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5713
  RTKHDAUD.sys                                        : 5.10.0.5713
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.2.0
  RTHDCPL.exe                                         : 2.2.4.6
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5713
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.248
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  RTSndMgr.cpl                                        : 1.0.0.10
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.77
  RtkApoApi.dll                                       : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.3.6
  RtkPgExt.dll                                        : 6.0.6000.61
  RtlCPAPI.dll                                        : 1.0.1.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5713
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.248
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.22
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.10
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.6
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.6
  RtkAPO64.dll                                        : 11.0.6000.77
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.61
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.64
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.05
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Meet Microsoft OEM Ready program requirements.
        2.) Package :
            1. Meet Microsoft OEM Ready program requirements.
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5708
  RTKHDAUD.sys                                        : 5.10.0.5708
  MicCal.exe                                          : 1.1.1.9
  RTHDCPL.exe                                         : 2.2.4.5
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.1
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5708
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.246
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  RTSndMgr.cpl                                        : 1.0.0.10
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  CTAPO32.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.76
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.5
  RtkPgExt.dll                                        : 6.0.6000.60
  RtlCPAPI.dll                                        : 1.0.1.9
  slcshp32.dll                                        : 1.0.3.0
  slgeq32.dll                                         : 1.0.1.0
  slh36032.dll                                        : 1.0.2.0
  slInit32.dll                                        : 1.1.1.0
  sltshd32.dll                                        : 1.1.0.0
  sluapo32.dll                                        : 1.2.6.0
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5708
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.246
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.1.1
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  GWfilt64.sys                                        : 6.10.0.3
  RTSnMg64.cpl                                        : 1.0.0.10
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  CTAPO32.dll                                         : 1.0.0.530
  CTAPO64.dll                                         : 1.0.0.530
  ctppld.dll                                          : 1.0.0.530
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.5
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.76
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.60
  slcshp64.dll                                        : 1.0.3.0
  slgeq64.dll                                         : 1.0.1.0
  slh36064.dll                                        : 1.0.2.0
  slInit64.dll                                        : 1.1.1.0
  sltshd64.dll                                        : 1.1.0.0
  sluapo64.dll                                        : 1.2.6.0
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.64
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.04
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273, ALC887
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273, ALC887
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Support ALC887.
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5700
  RTKHDAUD.sys                                        : 5.10.0.5700
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.4.0
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.0
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  AMBFilt64.sys                                       : 5.10.0.4240
  AMBFilt.sys                                         : 5.10.0.4240
  Monfilt64.sys                                       : 5.10.0.4115
  Monfilt.sys                                         : 5.10.0.4112
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5700
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.240
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  RTSndMgr.cpl                                        : 1.0.0.9
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  CTAPO32.dll                                         : 1.0.0.520
  ctppld.dll                                          : 1.0.0.510
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  ppchain.dll                                         : 1.0.0.70
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkAPO.dll                                          : 11.0.6000.74
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.2
  RtkPgExt.dll                                        : 6.0.6000.56
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  GWfilt64.sys                                        : 6.10.0.3
  RTKVHD64.sys                                        : 6.0.1.5700
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.240
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  RTSnMg64.cpl                                        : 1.0.0.9
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  CTAPO32.dll                                         : 1.0.0.520
  CTAPO64.dll                                         : 1.0.0.520
  ctppld.dll                                          : 1.0.0.510
  DaisyWrp.dll                                        : 1.0.0.70
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  ppchain.dll                                         : 1.0.0.70
  RCoInst64.dll                                       : 1.0.3.2
  RtCOM64.dll                                         : 2.0.0.100
  RTCOMDLL.dll                                        : 2.0.0.100
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.74
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.56
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.62
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.03
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5694
  RTKHDAUD.sys                                        : 5.10.0.5694
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.3.8
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.0
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.32
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5694
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.235
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  RTSndMgr.cpl                                        : 1.0.0.9
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkAPO.dll                                          : 11.0.6000.72
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.2
  RtkPgExt.dll                                        : 6.0.6000.54
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5694
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.235
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.21
  RTSnMg64.cpl                                        : 1.0.0.9
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.3.2
  RtCOM64.dll                                         : 2.0.0.99
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.72
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.54
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5692
  RtkUpd.exe                                          : 2.7.1.0
  RHCoInst.dll                                        : 1.0.3.2
  RHDMIExt.dll                                        : 6.0.6000.54
  RtkHDMI.dll                                         : 11.0.6000.72

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5692
  RtkUpd64.exe                                        : 2.7.1.0
  RHCoInst64.dll                                      : 1.0.3.2
  RHDMEx64.dll                                        : 6.0.6000.54
  RtkHDM64.dll                                        : 11.0.6000.72

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5692
  RtkUpd.exe                                          : 2.7.1.0
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5692
  RtkUpd64.exe                                        : 2.7.1.0

  Driver Setup Program                                : 2.62
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.02
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Update ForteMedia microphone effect library.

        2.) Package :
            1. Delete driver file by Rtlupd.exe in Windows 2000/2003/XP System . ( Rtlupd.exe 2.7.1.0 )
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5683
  RTKHDAUD.sys                                        : 5.10.0.5683
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.3.3
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.1.0
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5683
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.227
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkAPO.dll                                          : 11.0.6000.71
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.2
  RtkPgExt.dll                                        : 6.0.6000.53
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5683
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.227
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.1.0
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.3.2
  RtCOM64.dll                                         : 2.0.0.99
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.71
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.53
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5668
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.52
  RtkHDMI.dll                                         : 11.0.6000.69

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5668
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.52
  RtkHDM64.dll                                        : 11.0.6000.69

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5668
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5668
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.62
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.01
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272, ALC273
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272, ALC273
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Support ALC273.

        2.) Package :
            1. Change warning message for upgrade driver . 
            2. ChCfg.exe add version and manifest embedded feature .
            3. Add Manifest to Rtlupd.exe and HideWin.exe . 
            4. The SetCDfmt function was included by RtlExUpd.dll Ver.1.0.1.1
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5680
  RTKHDAUD.sys                                        : 5.10.0.5680
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.3.3
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5680
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.224
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkAPO.dll                                          : 11.0.6000.71
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.2
  RtkPgExt.dll                                        : 6.0.6000.53
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5680
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.224
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.3.2
  RtCOM64.dll                                         : 2.0.0.99
  RTCOMDLL.dll                                        : 2.0.0.99
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.71
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.53
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5668
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.52
  RtkHDMI.dll                                         : 11.0.6000.69

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5668
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.52
  RtkHDM64.dll                                        : 11.0.6000.69

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5668
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5668
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.61
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R2.00
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5672
  RTKHDAUD.sys                                        : 5.10.0.5672
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.3.1
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5672
  AERTSrv.exe                                         : 1.0.32.7
  RtHDVCpl.exe                                        : 1.0.0.219
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.70
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.1
  RtkPgExt.dll                                        : 6.0.6000.53
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5672
  AERTSr64.exe                                        : 1.0.64.7
  RAVCpl64.exe                                        : 1.0.0.219
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.19
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.3.1
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.70
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.53
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5668
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.52
  RtkHDMI.dll                                         : 11.0.6000.69

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5668
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.52
  RtkHDM64.dll                                        : 11.0.6000.69

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5668
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5668
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.60
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.99
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5667
  RTKHDAUD.sys                                        : 5.10.0.5667
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.3.0
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.11
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5667
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.215
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.18
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.69
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.3.1
  RtkPgExt.dll                                        : 6.0.6000.52
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5667
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.215
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.18
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.3.1
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.69
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.52
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5645
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.50
  RtkHDMI.dll                                         : 11.0.6000.67

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5645
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.50
  RtkHDM64.dll                                        : 11.0.6000.67

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5645
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5645
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.60
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.98
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix the potential risk that audio driver can't be installed completely under Vista.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5657
  RTKHDAUD.sys                                        : 5.10.0.5657
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.2.5
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5657
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.208
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.14
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.69
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.10
  RtkPgExt.dll                                        : 6.0.6000.52
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5657
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.208
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.14
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.10
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.69
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.52
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5645
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.50
  RtkHDMI.dll                                         : 11.0.6000.67

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5645
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.50
  RtkHDM64.dll                                        : 11.0.6000.67

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5645
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5645
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.60
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.97
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Add 24-bits recording feature.
            3. Fix EAX direct parameter issue under XP.
            4. Fix dummy noise issue under XP.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5653
  RTKHDAUD.sys                                        : 5.10.0.5653
  Alcmtr.exe                                          : 1.6.0.3
  AlcWzrd.exe                                         : 1.1.0.37
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.2.4
  RTLCPL.exe                                          : 1.0.1.66
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.31
  ALSndMgr.cpl                                        : 1.0.0.11
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5653
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.206
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.12
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.67
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.10
  RtkPgExt.dll                                        : 6.0.6000.50
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5653
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.206
  RtkAudioService.exe                                 : 1.0.0.16
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.1
  vncutil.exe                                         : 1.0.0.12
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.10
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.67
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.50
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5645
  RtkUpd.exe                                          : 2.7.0.9
  RHCoInst.dll                                        : 1.0.2.9
  RHDMIExt.dll                                        : 6.0.6000.50
  RtkHDMI.dll                                         : 11.0.6000.67

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5645
  RtkUpd64.exe                                        : 2.7.0.9
  RHCoInst64.dll                                      : 1.0.2.9
  RHDMEx64.dll                                        : 6.0.6000.50
  RtkHDM64.dll                                        : 11.0.6000.67

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5645
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5645
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.60
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.96
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.

        2.) Package :
            1. Fix uninstalled message_2 problem ( French language ) .

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5643
  RTKHDAUD.sys                                        : 5.10.0.5643
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.1.8
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  ALSndMgr.cpl                                        : 1.0.0.10
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.97
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5643
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.198
  RtkAudioService.exe                                 : 1.0.0.14
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  vncutil.exe                                         : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.67
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.6
  RtkPgExt.dll                                        : 6.0.6000.49
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5643
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.198
  RtkAudioService.exe                                 : 1.0.0.14
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  vncutil.exe                                         : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.6
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.67
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.49
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5633
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.48
  RtkHDMI.dll                                         : 11.0.6000.66

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5633
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.48
  RtkHDM64.dll                                        : 11.0.6000.66

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5633
  RtkUpd.exe                                          : 2.7.0.9
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5633
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.60
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.95
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix encryption stream issue for ALC889.
            3. Fix DRM issue. 

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5636
  RTKHDAUD.sys                                        : 5.10.0.5636
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.1.6
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  ALSndMgr.cpl                                        : 1.0.0.10
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  RTKVHDA.sys                                         : 6.0.1.5636
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.192
  RtkAudioService.exe                                 : 1.0.0.12
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  vncutil.exe                                         : 1.0.0.5
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkAPO.dll                                          : 11.0.6000.66
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.5
  RtkPgExt.dll                                        : 6.0.6000.48
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5636
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.192
  RtkAudioService.exe                                 : 1.0.0.12
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  vncutil.exe                                         : 1.0.0.5
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.5
  RtCOM64.dll                                         : 2.0.0.98
  RTCOMDLL.dll                                        : 2.0.0.98
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.66
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.48
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5612
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.44
  RtkHDMI.dll                                         : 11.0.6000.63

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5612
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.44
  RtkHDM64.dll                                        : 11.0.6000.63

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5612
  RtkUpd.exe                                          : 2.7.0.9

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5612
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.59
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.94
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Zero recorded data for SPDIF-IN copy-protection stream under Vista.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5628
  RTKHDAUD.sys                                        : 5.10.0.5628
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.1.3
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd.exe                                          : 2.7.0.9
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  ALSndMgr.cpl                                        : 1.0.0.10
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  RTKVHDA.sys                                         : 6.0.1.5628
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.188
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSndMgr.cpl                                        : 1.0.0.8
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkAPO.dll                                          : 11.0.6000.65
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.3
  RtkPgExt.dll                                        : 6.0.6000.47
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5628
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.188
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSnMg64.cpl                                        : 1.0.0.8
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.3
  RtCOM64.dll                                         : 2.0.0.97
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.65
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.47
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5612
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.44
  RtkHDMI.dll                                         : 11.0.6000.63

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5612
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.44
  RtkHDM64.dll                                        : 11.0.6000.63

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5612
  RtkUpd.exe                                          : 2.7.0.9

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5612
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.59
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.93
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
        2.) Package :
            1. Small VGA mode should not be checked in silent installation . 

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5624
  RTKHDAUD.sys                                        : 5.10.0.5624
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.1.1
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  ALSndMgr.cpl                                        : 1.0.0.10
  RTSndMgr.cpl                                        : 1.0.1.0
  RTCOMDLL.dll                                        : 1.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  RTKVHDA.sys                                         : 6.0.1.5624
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.185
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSndMgr.cpl                                        : 1.0.0.7
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.59.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkAPO.dll                                          : 11.0.6000.65
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.3
  RtkPgExt.dll                                        : 6.0.6000.46
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.1.0.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5624
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.185
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSnMg64.cpl                                        : 1.0.0.7
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.59.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.3
  RtCOM64.dll                                         : 2.0.0.97
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.65
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.46
  SRSHP64.dll                                         : 1.1.0.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5612
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.44
  RtkHDMI.dll                                         : 11.0.6000.63

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5612
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.44
  RtkHDM64.dll                                        : 11.0.6000.63

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5612
  RtkUpd.exe                                          : 2.7.0.9

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5612
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.59
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.92
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix Stereo Mix issue with codec which support capless output pin.
            2. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5618
  RTKHDAUD.sys                                        : 5.10.0.5618
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.1.0
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.10
  RTCOMDLL.dll                                        : 1.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5618
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.183
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSndMgr.cpl                                        : 1.0.0.7
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 40.58.0.0
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.13.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkAPO.dll                                          : 11.0.6000.64
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.1
  RtkPgExt.dll                                        : 6.0.6000.45
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5618
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.183
  RtkAudioService.exe                                 : 1.0.0.12
  RtkSmbus.exe                                        : 1.0.0.2
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSnMg64.cpl                                        : 1.0.0.7
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 40.58.0.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.1
  RtCOM64.dll                                         : 2.0.0.97
  RTCOMDLL.dll                                        : 2.0.0.97
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.64
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.45
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5612
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.44
  RtkHDMI.dll                                         : 11.0.6000.63

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5612
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.44
  RtkHDM64.dll                                        : 11.0.6000.63

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5612
  RtkUpd.exe                                          : 2.7.0.9

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5612
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.58
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.91
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix DTM 1.2 KS topology test fail issue.
            2. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  RTKHDA64.sys                                        : 5.10.0.5605
  RTKHDAUD.sys                                        : 5.10.0.5605
  MicCal.exe                                          : 1.1.1.8
  RTHDCPL.exe                                         : 2.2.0.2
  RTLCPL.exe                                          : 1.0.1.65
  RtlUpd64.exe                                        : 2.7.0.9
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  SoundMan.exe                                        : 1.0.0.30
  Alcmtr.exe                                          : 1.6.0.2
  AlcWzrd.exe                                         : 1.1.0.36
  RTSndMgr.cpl                                        : 1.0.1.0
  ALSndMgr.cpl                                        : 1.0.0.10
  RTCOMDLL.dll                                        : 1.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86
  RTKVHDA.sys                                         : 6.0.1.5605
  AERTSrv.exe                                         : 1.0.32.2
  RtHDVCpl.exe                                        : 1.0.0.172
  RtkAudioService.exe                                 : 1.0.0.11
  RtkSmbus.exe                                        : 1.0.0.1
  RtlUpd.exe                                          : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSndMgr.cpl                                        : 1.0.0.7
  AERTACap.dll                                        : 1.0.32.7
  AERTARen.dll                                        : 1.0.32.3
  FMAPO.dll                                           : 6.0.6000.16386
  MaxxAudioAPO.dll                                    : 1.2.2.0
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  MaxxAudioEQ.dll                                     : 5.9.7.0
  RTCOMDLL.dll                                        : 2.0.0.96
  RtkAPO.dll                                          : 11.0.6000.63
  RtkApoApi.dll                                       : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.2.0
  RtkPgExt.dll                                        : 6.0.6000.42
  RtlCPAPI.dll                                        : 1.0.1.9
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  WavesLib.dll                                        : 5.9.7.0
  Vista driver for x64
  RTKVHD64.sys                                        : 6.0.1.5605
  AERTSr64.exe                                        : 1.0.64.2
  RAVCpl64.exe                                        : 1.0.0.172
  RtkAudioService.exe                                 : 1.0.0.11
  RtkSmbus.exe                                        : 1.0.0.1
  RtlUpd64.exe                                        : 2.7.0.9
  SkyTel.exe                                          : 2.0.2.0
  RTSnMg64.cpl                                        : 1.0.0.7
  AERTAC64.dll                                        : 1.0.64.7
  AERTAR64.dll                                        : 1.0.64.3
  FMAPO64.dll                                         : 6.0.6000.16386
  MaxxAudioAPO20.dll                                  : 2.0.12.0
  RCoInst64.dll                                       : 1.0.2.0
  RtCOM64.dll                                         : 2.0.0.96
  RTCOMDLL.dll                                        : 2.0.0.96
  RtkApi64.dll                                        : 1.0.0.4
  RtkAPO64.dll                                        : 11.0.6000.63
  RtlCPAPI.dll                                        : 1.0.1.9
  RtPgEx64.dll                                        : 6.0.6000.42
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
HDMI Driver : ---------------------------------------------------------
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5602
  RtkUpd.exe                                          : 2.7.0.9
  RHDMIExt.dll                                        : 6.0.6000.42
  RtkHDMI.dll                                         : 11.0.6000.62

  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5602
  RtkUpd64.exe                                        : 2.7.0.9
  RHDMEx64.dll                                        : 6.0.6000.42
  RtkHDM64.dll                                        : 11.0.6000.62

  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5602
  RtkUpd.exe                                          : 2.7.0.9

  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5602
  RtkUpd64.exe                                        : 2.7.0.9

  Driver Setup Program                                : 2.58
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.90
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262,ALC267, ALC268, ALC269, ALC272
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC663, ALC260, ALC262, ALC267,ALC268, ALC269, ALC272
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Support ALC663/ALC272.
            2. Support ForteMedia microphone effect APO feature.
            3. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5591
  WDM driver for Winx64                               : 5.10.0.5591
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.1.0
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.9.6
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5591
  RtHDVCpl.exe                                        : 1.0.0.159
  RtkAPO.dll                                          : 11.0.6000.60
  RtkPgExt.dll                                        : 6.0.6000.40
  RTCOMDLL.dll                                        : 2.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.8
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.29
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5591
  RAVCpl64.exe                                        : 1.0.0.159
  RtkAPO64.dll                                        : 11.0.6000.60
  RtPgEx64.dll                                        : 6.0.6000.40
  RTCOMDLL.dll                                        : 2.0.0.96
  RtlCPAPI.dll                                        : 1.0.1.8
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.29
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5575
  RtkHDM64.dll                                        : 6.0.6000.57
  RHDMEx64.dll                                        : 6.0.6000.39
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5575
  RtkHDMI.dll                                         : 6.0.6000.57
  RHDMIExt.dll                                        : 6.0.6000.39
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5575
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5575

  Driver Setup Program                                : 2.57
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.89
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Support "Event/Notification mode" under Vista.
            2. Fix Vista GUI issue when video adapter's resolution is low.
            3. Customizations.
        2.) Package :
            1. Uninstallation language selected by OS system .
            2. "Uninstall" word issue in Japanese language .

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5582
  WDM driver for Winx64                               : 5.10.0.5582
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.9.3
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5582
  RtHDVCpl.exe                                        : 1.0.0.153
  RtkAPO.dll                                          : 11.0.6000.59
  RtkPgExt.dll                                        : 6.0.6000.40
  RTCOMDLL.dll                                        : 2.0.0.93
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.27
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5582
  RAVCpl64.exe                                        : 1.0.0.153
  RtkAPO64.dll                                        : 11.0.6000.59
  RtPgEx64.dll                                        : 6.0.6000.40
  RTCOMDLL.dll                                        : 2.0.0.93
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.27
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5575
  RtkHDM64.dll                                        : 6.0.6000.57
  RHDMEx64.dll                                        : 6.0.6000.39
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5575
  RtkHDMI.dll                                         : 6.0.6000.57
  RHDMIExt.dll                                        : 6.0.6000.39
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5575
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5575

  Driver Setup Program                                : 2.56
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.88
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix BSOD issue for WLK 1.1 System-Common Scenario Stress With IO test and System-Disable Enable With IO test under XP.
            2. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5574
  WDM driver for Winx64                               : 5.10.0.5574
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.9.1
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5574
  RtHDVCpl.exe                                        : 1.0.0.145
  RtkAPO.dll                                          : 11.0.6000.58
  RtkPgExt.dll                                        : 6.0.6000.38
  RTCOMDLL.dll                                        : 2.0.0.90
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.25
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5574
  RAVCpl64.exe                                        : 1.0.0.145
  RtkAPO64.dll                                        : 11.0.6000.58
  RtPgEx64.dll                                        : 6.0.6000.38
  RTCOMDLL.dll                                        : 2.0.0.90
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.25
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.55
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.87
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix recording issue for ALC269.
            2. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5567
  WDM driver for Winx64                               : 5.10.0.5567
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.8.9
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5567
  RtHDVCpl.exe                                        : 1.0.0.139
  RtkAPO.dll                                          : 11.0.6000.56
  RtkPgExt.dll                                        : 6.0.6000.35
  RTCOMDLL.dll                                        : 2.0.0.89
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.25
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5567
  RAVCpl64.exe                                        : 1.0.0.139
  RtkAPO64.dll                                        : 11.0.6000.56
  RtPgEx64.dll                                        : 6.0.6000.35
  RTCOMDLL.dll                                        : 2.0.0.89
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.25
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.54
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.86
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC889, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix the issue that SPDIF-out device broadcast 2nd output device's stream when turn on multi-streaming under Windows XP.
            2. Indexed DRC file supported.
            3. Customizations.
        2.) Package :
            1. Installer failed code.
            2. Copy .dat file rule.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5559
  WDM driver for Winx64                               : 5.10.0.5559
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.8.7
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5559
  RtHDVCpl.exe                                        : 1.0.0.132
  RtkAPO.dll                                          : 11.0.6000.54
  RtkPgExt.dll                                        : 6.0.6000.35
  RTCOMDLL.dll                                        : 2.0.0.87
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.25
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5559
  RAVCpl64.exe                                        : 1.0.0.132
  RtkAPO64.dll                                        : 11.0.6000.54
  RtPgEx64.dll                                        : 6.0.6000.35
  RTCOMDLL.dll                                        : 2.0.0.87
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.25
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.52
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.85
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix PC-Beep mute issue for ALC268/ALC267.
            2. Fix the potential risk that system-thread is still running when driver is already unloaded under Vista.
            3. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5548
  WDM driver for Winx64                               : 5.10.0.5548
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.8.6
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5548
  RtHDVCpl.exe                                        : 1.0.0.128
  RtkAPO.dll                                          : 11.0.6000.51
  RtkPgExt.dll                                        : 6.0.6000.33
  RTCOMDLL.dll                                        : 2.0.0.86
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.25
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.3
  Vista driver for x64                                : 6.0.1.5548
  RAVCpl64.exe                                        : 1.0.0.128
  RtkAPO64.dll                                        : 11.0.6000.51
  RtPgEx64.dll                                        : 6.0.6000.33
  RTCOMDLL.dll                                        : 2.0.0.86
  RtlCPAPI.dll                                        : 1.0.1.7
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.25
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.3
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.51
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.84
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Fix potential risk for re-direct headphone mode under Vista.
            2. Customizations.

     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5532
  WDM driver for Winx64                               : 5.10.0.5532
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.8.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5532
  RtHDVCpl.exe                                        : 1.0.0.116
  RtkAPO.dll                                          : 11.0.6000.48
  RtkPgExt.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.86
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.18
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5532
  RAVCpl64.exe                                        : 1.0.0.116
  RtkAPO64.dll                                        : 11.0.6000.48
  RtPgEx64.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.86
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.18
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.51
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.83
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268, ALC269
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268, ALC269
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Support ALC269.
            2. Customizations.
            3. Turn on amplifier mask control for ALC885.
            4. Fix volume issue when turn on "Limited Output" feature under Windows XP.
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5523
  WDM driver for Winx64                               : 5.10.0.5523
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.7.7
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.2.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5523
  RtHDVCpl.exe                                        : 1.0.0.112
  RtkAPO.dll                                          : 11.0.6000.48
  RtkPgExt.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.85
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.15
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5523
  RAVCpl64.exe                                        : 1.0.0.112
  RtkAPO64.dll                                        : 11.0.6000.48
  RtPgEx64.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.85
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.15
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.51
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.82
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Support IMiniportWaveRTStreamNotification interface under Vista.
            2. Customizations.
            3. Fix bug for the specific customer. 
        2.) Installer :
            1. Add silent uninstall option .
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5512
  WDM driver for Winx64                               : 5.10.0.5512
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.7.1
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.21
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5512
  RtHDVCpl.exe                                        : 1.0.0.106
  RtkAPO.dll                                          : 11.0.6000.48
  RtkPgExt.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.83
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.7
  RtkCoInst.dll                                       : 1.0.1.13
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5512
  RAVCpl64.exe                                        : 1.0.0.106
  RtkAPO64.dll                                        : 11.0.6000.48
  RtPgEx64.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.83
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.7
  RCoInst64.dll                                       : 1.0.1.13
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.51
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.81
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Support real 2.1 output capability under Vista.
            2. Improve Doppler effect for XP driver.
            3. Fix Vista DTM topology testing issue.
            4. Fix dead lock issue when more than 3 jacks set as headphone output under XP.
        2.) Installer :
            1. VSS event error for InstallShield .
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5506
  WDM driver for Winx64                               : 5.10.0.5506
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.7.0
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.21
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5506
  RtHDVCpl.exe                                        : 1.0.0.103
  RtkAPO.dll                                          : 11.0.6000.48
  RtkPgExt.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.82
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.13
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5506
  RAVCpl64.exe                                        : 1.0.0.103
  RtkAPO64.dll                                        : 11.0.6000.48
  RtPgEx64.dll                                        : 6.0.6000.31
  RTCOMDLL.dll                                        : 2.0.0.82
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.13
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.50
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.80
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Add new feature to smooth gap between 2 different output stream under Vista.
        2.) Installer :
            1. "Program Compatibility Assistant" issue for InstallShield 11.5 .
            2. VSR stop setting .
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5497
  WDM driver for Winx64                               : 5.10.0.5497
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.6.7
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.21
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5497
  RtHDVCpl.exe                                        : 1.0.0.99
  RtkAPO.dll                                          : 11.0.6000.45
  RtkPgExt.dll                                        : 6.0.6000.30
  RTCOMDLL.dll                                        : 2.0.0.80
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.10
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5497
  RAVCpl64.exe                                        : 1.0.0.99
  RtkAPO64.dll                                        : 11.0.6000.45
  RtPgEx64.dll                                        : 6.0.6000.30
  RTCOMDLL.dll                                        : 2.0.0.80
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.10
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.49
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.79
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Driver :
            1. Customizations.
            2. Fix potential risk from dividing by zero while the input signal power approach zero under Windows XP.
            3. Support digital mic software boost for ALC888.
        2.) Installer :
            1. Remove Realtek registry key in upgrade mode.
            2. Change MCE GUI installation procedure for Windows Vista by Microsoft requirement.
            3. Add install procedure for VSR feature.
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5490
  WDM driver for Winx64                               : 5.10.0.5490
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.6.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5490
  RtHDVCpl.exe                                        : 1.0.0.96
  RtkAPO.dll                                          : 11.0.6000.45
  RtkPgExt.dll                                        : 6.0.6000.30
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.9
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5490
  RAVCpl64.exe                                        : 1.0.0.96
  RtkAPO64.dll                                        : 11.0.6000.45
  RtPgEx64.dll                                        : 6.0.6000.30
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.9
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.47
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.78
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.
        
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5485
  WDM driver for Winx64                               : 5.10.0.5485
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.6.0
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5485
  RtHDVCpl.exe                                        : 1.0.0.92
  RtkAPO.dll                                          : 11.0.6000.45
  RtkPgExt.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.8
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5485
  RAVCpl64.exe                                        : 1.0.0.92
  RtkAPO64.dll                                        : 11.0.6000.45
  RtPgEx64.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.8
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.45
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.77
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.
        2.) Uninstall procedure for checking Rtlupd.exe file .
     
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5480
  WDM driver for Winx64                               : 5.10.0.5480
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.5.7
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5480
  RtHDVCpl.exe                                        : 1.0.0.90
  RtkAPO.dll                                          : 11.0.6000.45
  RtkPgExt.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5480
  RAVCpl64.exe                                        : 1.0.0.90
  RtkAPO64.dll                                        : 11.0.6000.45
  RtPgEx64.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.45
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.76
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
        2.) Installer package language wrong for Japanese translation . ( Upgrade operation for Vista )
      
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5477
  WDM driver for Winx64                               : 5.10.0.5477
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.5.5
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5477
  RtHDVCpl.exe                                        : 1.0.0.89
  RtkAPO.dll                                          : 11.0.6000.45
  RtkPgExt.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5477
  RAVCpl64.exe                                        : 1.0.0.89
  RtkAPO64.dll                                        : 11.0.6000.45
  RtPgEx64.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RCoInst64.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.44
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.75
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5473
  WDM driver for Winx64                               : 5.10.0.5473
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.5.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5473
  RtHDVCpl.exe                                        : 1.0.0.88
  RtkAPO.dll                                          : 11.0.6000.44
  RtkPgExt.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5473
  RAVCpl64.exe                                        : 1.0.0.88
  RtkAPO64.dll                                        : 11.0.6000.44
  RtPgEx64.dll                                        : 6.0.6000.29
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.42
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.74
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5470
  WDM driver for Winx64                               : 5.10.0.5470
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.5.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5470
  RtHDVCpl.exe                                        : 1.0.0.87
  RtkAPO.dll                                          : 11.0.6000.44
  RtkPgExt.dll                                        : 6.0.6000.28
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5470
  RAVCpl64.exe                                        : 1.0.0.87
  RtkAPO64.dll                                        : 11.0.6000.44
  RtPgEx64.dll                                        : 6.0.6000.28
  RTCOMDLL.dll                                        : 2.0.0.79
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.40
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.73
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5464
  WDM driver for Winx64                               : 5.10.0.5464
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.4.9
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.20
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5464
  RtHDVCpl.exe                                        : 1.0.0.84
  RtkAPO.dll                                          : 11.0.6000.43
  RtkPgExt.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.76
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.3.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5464
  RAVCpl64.exe                                        : 1.0.0.84
  RtkAPO64.dll                                        : 11.0.6000.43
  RtPgEx64.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.76
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.3.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.38
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.72
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5449
  WDM driver for Winx64                               : 5.10.0.5449
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.4.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.19
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5449
  RtHDVCpl.exe                                        : 1.0.0.73
  RtkAPO.dll                                          : 11.0.6000.41
  RtkPgExt.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.76
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5449
  RAVCpl64.exe                                        : 1.0.0.73
  RtkAPO64.dll                                        : 11.0.6000.41
  RtPgEx64.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.76
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.36
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.71
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5443
  WDM driver for Winx64                               : 5.10.0.5443
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.4.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.19
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5443
  RtHDVCpl.exe                                        : 1.0.0.73
  RtkAPO.dll                                          : 11.0.6000.40
  RtkPgExt.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5443
  RAVCpl64.exe                                        : 1.0.0.73
  RtkAPO64.dll                                        : 11.0.6000.40
  RtPgEx64.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.6
  RtkCoInst.dll                                       : 1.0.1.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.36
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.70
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262,ALC267, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5436
  WDM driver for Winx64                               : 5.10.0.5436
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.9
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.19
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5436
  RtHDVCpl.exe                                        : 1.0.0.69
  RtkAPO.dll                                          : 11.0.6000.38
  RtkPgExt.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.5
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5436
  RAVCpl64.exe                                        : 1.0.0.69
  RtkAPO64.dll                                        : 11.0.6000.38
  RtPgEx64.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.5
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.35
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.69
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5433
  WDM driver for Winx64                               : 5.10.0.5433
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.6
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.17
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5433
  RtHDVCpl.exe                                        : 1.0.0.68
  RtkAPO.dll                                          : 11.0.6000.38
  RtkPgExt.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.5
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.4.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5433
  RAVCpl64.exe                                        : 1.0.0.68
  RtkAPO64.dll                                        : 11.0.6000.38
  RtPgEx64.dll                                        : 6.0.6000.27
  RTCOMDLL.dll                                        : 2.0.0.74
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.5
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.4.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.34
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.68
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5413
  WDM driver for Winx64                               : 5.10.0.5413
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.12
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5413
  RtHDVCpl.exe                                        : 1.0.0.60
  RtkAPO.dll                                          : 11.0.6000.37
  RtkPgExt.dll                                        : 6.0.6000.25
  RTCOMDLL.dll                                        : 2.0.0.73
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.2
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.3.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5413
  RAVCpl64.exe                                        : 1.0.0.60
  RtkAPO64.dll                                        : 11.0.6000.37
  RtPgEx64.dll                                        : 6.0.6000.25
  RTCOMDLL.dll                                        : 2.0.0.73
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.2
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.3.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5413
  RtkHDM64.dll                                        : 6.0.6000.37
  RHDMEx64.dll                                        : 6.0.6000.25
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5413
  RtkHDMI.dll                                         : 6.0.6000.37
  RHDMIExt.dll                                        : 6.0.6000.25
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5413
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5413

  Driver Setup Program                                : 2.33
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.67
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5413
  WDM driver for Winx64                               : 5.10.0.5413
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.12
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5413
  RtHDVCpl.exe                                        : 1.0.0.60
  RtkAPO.dll                                          : 11.0.6000.37
  RtkPgExt.dll                                        : 6.0.6000.25
  RTCOMDLL.dll                                        : 2.0.0.73
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.2
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.1.0
  SRSTSHD.dll                                         : 1.1.3.0
  RtkApoApi.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5413
  RAVCpl64.exe                                        : 1.0.0.60
  RtkAPO64.dll                                        : 11.0.6000.37
  RtPgEx64.dll                                        : 6.0.6000.25
  RTCOMDLL.dll                                        : 2.0.0.73
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.2
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.1.0
  SRSTSH64.dll                                        : 1.1.3.0
  RtkApi64.dll                                        : 1.0.0.2
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.32
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.66
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5404
  WDM driver for Winx64                               : 5.10.0.5404
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.2
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.11
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5404
  RtHDVCpl.exe                                        : 1.0.0.54
  RtkAPO.dll                                          : 11.0.6000.35
  RtkPgExt.dll                                        : 6.0.6000.24
  RTCOMDLL.dll                                        : 2.0.0.72
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.1
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.1.2.0
  SRSHP360.dll                                        : 1.0.0.0
  SRSTSHD.dll                                         : 1.1.2.0
  Vista driver for x64                                : 6.0.1.5404
  RAVCpl64.exe                                        : 1.0.0.54
  RtkAPO64.dll                                        : 11.0.6000.35
  RtPgEx64.dll                                        : 6.0.6000.24
  RTCOMDLL.dll                                        : 2.0.0.72
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.1
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.1.2.0
  SRSHP64.dll                                         : 1.0.0.0
  SRSTSH64.dll                                        : 1.1.2.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.32
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.65
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5397
  WDM driver for Winx64                               : 5.10.0.5397
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.3.0
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.9
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5397
  RtHDVCpl.exe                                        : 1.0.0.50
  RtkAPO.dll                                          : 11.0.6000.32
  RtkPgExt.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.70
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.1
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5397
  RAVCpl64.exe                                        : 1.0.0.50
  RtkAPO64.dll                                        : 11.0.6000.32
  RtPgEx64.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.70
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.1.1
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.31
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.64
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5391
  WDM driver for Winx64                               : 5.10.0.5391
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.65
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.9
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 2.0.1.7
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5391
  RtHDVCpl.exe                                        : 1.0.0.46
  RtkAPO.dll                                          : 11.0.6000.31
  RtkPgExt.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.0.12
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5391
  RAVCpl64.exe                                        : 1.0.0.46
  RtkAPO64.dll                                        : 11.0.6000.31
  RtPgEx64.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.5
  RtkCoInst.dll                                       : 1.0.0.12
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.30
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.63
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5377
  WDM driver for Winx64                               : 5.10.0.5377
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.4
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5386
  RtHDVCpl.exe                                        : 1.0.0.43
  RtkAPO.dll                                          : 11.0.6000.29
  RtkPgExt.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.9
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5386
  RAVCpl64.exe                                        : 1.0.0.43
  RtkAPO64.dll                                        : 11.0.6000.29
  RtPgEx64.dll                                        : 6.0.6000.22
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.9
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.30
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.62
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5377
  WDM driver for Winx64                               : 5.10.0.5377
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.4
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5384
  RtHDVCpl.exe                                        : 1.0.0.41
  RtkAPO.dll                                          : 11.0.6000.28
  RtkPgExt.dll                                        : 6.0.6000.21
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.9
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5384
  RAVCpl64.exe                                        : 1.0.0.41
  RtkAPO64.dll                                        : 11.0.6000.28
  RtPgEx64.dll                                        : 6.0.6000.21
  RTCOMDLL.dll                                        : 2.0.0.69
  RtlCPAPI.dll                                        : 1.0.1.6
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.9
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5368
  RtkHDM64.dll                                        : 6.0.6000.26
  RHDMEx64.dll                                        : 6.0.6000.20
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5368
  RtkHDMI.dll                                         : 6.0.6000.26
  RHDMIExt.dll                                        : 6.0.6000.20
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5368
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5368

  Driver Setup Program                                : 2.30
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.61
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5377
  WDM driver for Winx64                               : 5.10.0.5377
  Realtek Soundman                                    : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.4
  Alcwzrd.exe                                         : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5377
  RtHDVCpl.exe                                        : 1.0.0.38
  RtkAPO.dll                                          : 11.0.6000.26
  RtkPgExt.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.68
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5377
  RAVCpl64.exe                                        : 1.0.0.38
  RtkAPO64.dll                                        : 11.0.6000.26
  RtPgEx64.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.68
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5356
  RtkHDM64.dll                                        : 6.0.6000.20
  RHDMEx64.dll                                        : 6.0.6000.17
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5356
  RtkHDMI.dll                                         : 6.0.6000.20
  RHDMIExt.dll                                        : 6.0.6000.17
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5356
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5356

  Driver Setup Program                                : 2.30
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.60
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5366
  WDM driver for Winx64                               : 5.10.0.5366
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5374
  RtHDVCpl.exe                                        : 1.0.0.36
  RtkAPO.dll                                          : 11.0.6000.25
  RtkPgExt.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.66
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5374
  RAVCpl64.exe                                        : 1.0.0.36
  RtkAPO64.dll                                        : 11.0.6000.25
  RtPgEx64.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5356
  RtkHDM64.dll                                        : 6.0.6000.20
  RHDMEx64.dll                                        : 6.0.6000.17
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5356
  RtkHDMI.dll                                         : 6.0.6000.20
  RHDMIExt.dll                                        : 6.0.6000.17
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5356
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5356

  Driver Setup Program                                : 2.28
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.59
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5366
  WDM driver for Winx64                               : 5.10.0.5366
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5372
  RtHDVCpl.exe                                        : 1.0.0.33
  RtkAPO.dll                                          : 11.0.6000.25
  RtkPgExt.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.66
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5372
  RAVCpl64.exe                                        : 1.0.0.33
  RtkAPO64.dll                                        : 11.0.6000.25
  RtPgEx64.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5356
  RtkHDM64.dll                                        : 6.0.6000.20
  RHDMEx64.dll                                        : 6.0.6000.17
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5356
  RtkHDMI.dll                                         : 6.0.6000.20
  RHDMIExt.dll                                        : 6.0.6000.17
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5356
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5356

  Driver Setup Program                                : 2.28
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.58
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5366
  WDM driver for Winx64                               : 5.10.0.5366
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5371
  RtHDVCpl.exe                                        : 1.0.0.32
  RtkAPO.dll                                          : 11.0.6000.25
  RtkPgExt.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.66
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5371
  RAVCpl64.exe                                        : 1.0.0.32
  RtkAPO64.dll                                        : 11.0.6000.25
  RtPgEx64.dll                                        : 6.0.6000.20
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.4
  RtkCoInst.dll                                       : 1.0.0.7
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5356
  RtkHDM64.dll                                        : 6.0.6000.20
  RHDMEx64.dll                                        : 6.0.6000.17
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5356
  RtkHDMI.dll                                         : 6.0.6000.20
  RHDMIExt.dll                                        : 6.0.6000.17
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5356
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5356

  Driver Setup Program                                : 2.28
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.57
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. HDMI Device WHQL Support: ATI HDMI Devices
    4. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    5. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    6. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
Windows 2000/XP : -----------------------------------------------------
  WDM driver for Win2000/WinXP                        : 5.10.0.5366
  WDM driver for Winx64                               : 5.10.0.5366
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.2.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
Vista driver : --------------------------------------------------------
  Vista driver for x86                                : 6.0.1.5361
  RtHDVCpl.exe                                        : 1.0.0.27
  RtkAPO.dll                                          : 11.0.6000.20
  RtkPgExt.dll                                        : 6.0.6000.17
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.6
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5361
  RAVCpl64.exe                                        : 1.0.0.27
  RtkAPO64.dll                                        : 11.0.6000.20
  RtPgEx64.dll                                        : 6.0.6000.17
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.6
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0
HDMI Driver : ---------------------------------------------------------
  Vista x64:
  RtHDMIVX.sys                                        : 6.0.1.5356
  RtkHDM64.dll                                        : 6.0.6000.20
  RHDMEx64.dll                                        : 6.0.6000.17
  Vista x86:
  RtHDMIV.sys                                         : 6.0.1.5356
  RtkHDMI.dll                                         : 6.0.6000.20
  RHDMIExt.dll                                        : 6.0.6000.17
  XP/2K x64:
  RtHDMIX.sys                                         : 5.10.0.5356
  XP/2K x86:
  RtHDMI.sys                                          : 5.10.0.5356

  Driver Setup Program                                : 2.27
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.56
    Realtek HD Audio Driver support all of Realtek HD Audio Codec in Vista/WinXP/Win2000/Win2003 .
    1. Vista WHQL Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP WHQL Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5345
  WDM driver for Winx64                               : 5.10.0.5345
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.4
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5361
  RtHDVCpl.exe                                        : 1.0.0.27
  RtkAPO.dll                                          : 11.0.6000.20
  RtkPgExt.dll                                        : 6.0.6000.17
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.6
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5361
  RAVCpl64.exe                                        : 1.0.0.27
  RtkAPO64.dll                                        : 11.0.6000.20
  RtPgEx64.dll                                        : 6.0.6000.17
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.6
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0

  Driver Setup Program                                : 2.27
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.55
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5345
  WDM driver for Winx64                               : 5.10.0.5345
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.4
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5350
  RtHDVCpl.exe                                        : 1.0.0.21
  RtkAPO.dll                                          : 11.0.6000.16
  RtkPgExt.dll                                        : 6.0.6000.15
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.3
  SRSTSXT.dll                                         : 3.2.0.0
  SRSWOW.dll                                          : 1.0.6.0
  Vista driver for x64                                : 6.0.1.5350
  RAVCpl64.exe                                        : 1.0.0.21
  RtkAPO64.dll                                        : 11.0.6000.16
  RtPgEx64.dll                                        : 6.0.6000.15
  RTCOMDLL.dll                                        : 2.0.0.65
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.4
  SRSTSX64.dll                                        : 3.2.0.0
  SRSWOW64.dll                                        : 1.0.6.0

  Driver Setup Program                                : 2.24
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.54
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        
       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5345
  WDM driver for Winx64                               : 5.10.0.5345
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.4
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5334
  RtHDVCpl.exe                                        : 1.0.0.11
  RtkAPO.dll                                          : 11.0.5600.13
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5334
  RAVCpl64.exe                                        : 1.0.0.11
  RtkAPO64.dll                                        : 11.0.5600.13
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.2

  Driver Setup Program                                : 2.23
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.53
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Fixed issue -> DTM Test \ Hal timer issue for V5331 Vista driver ( Potential risk ).

       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5324
  WDM driver for Winx64                               : 5.10.0.5324
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.1
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5334
  RtHDVCpl.exe                                        : 1.0.0.11
  RtkAPO.dll                                          : 11.0.5600.13
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.2
  Vista driver for x64                                : 6.0.1.5334
  RAVCpl64.exe                                        : 1.0.0.11
  RtkAPO64.dll                                        : 11.0.5600.13
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.1.5
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.2

  Driver Setup Program                                : 2.21
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.52
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Known issue -> DTM Test \ Hal timer issue for V5331 Vista driver ( Potential risk ).

       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5324
  WDM driver for Winx64                               : 5.10.0.5324
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.1
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5331
  RtHDVCpl.exe                                        : 1.0.0.9
  RtkAPO.dll                                          : 11.0.5600.13
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.1
  Vista driver for x64                                : 6.0.1.5331
  RAVCpl64.exe                                        : 1.0.0.9
  RtkAPO64.dll                                        : 11.0.5600.13
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.1
  RtkCoInst.dll                                       : 1.0.0.1

  Driver Setup Program                                : 2.20
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.51
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC267,ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5324
  WDM driver for Winx64                               : 5.10.0.5324
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.1.1
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5322
  RtHDVCpl.exe                                        : 1.0.0.7
  RtkAPO.dll                                          : 11.0.5600.13
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.1
  Vista driver for x64                                : 6.0.1.5322
  RAVCpl64.exe                                        : 1.0.0.7
  RtkAPO64.dll                                        : 11.0.5600.13
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.1
  Driver Setup Program                                : 2.20
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.50
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5319
  WDM driver for Winx64                               : 5.10.0.5319
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.0.8
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5322
  RtHDVCpl.exe                                        : 1.0.0.7
  RtkAPO.dll                                          : 11.0.5600.13
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.1
  Vista driver for x64                                : 6.0.1.5322
  RAVCpl64.exe                                        : 1.0.0.7
  RtkAPO64.dll                                        : 11.0.5600.13
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.1
  Driver Setup Program                                : 2.19
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.49
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. Windows 2000/XP logo Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861VC, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    3. OS Supporting: Microsoft Windows XP, Windows 2000, Vista x86/x64
    4. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    5. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  Windows 2000/XP :
  WDM driver for Win2000/WinXP                        : 5.10.0.5319
  WDM driver for Winx64                               : 5.10.0.5319
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.1.0.8
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Vista driver :
  Vista driver for x86                                : 6.0.1.5317
  RtHDVCpl.exe                                        : 1.0.0.6
  RtkAPO.dll                                          : 11.0.5600.12
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.1
  Vista driver for x64                                : 6.0.1.5317
  RAVCpl64.exe                                        : 1.0.0.6
  RtkAPO64.dll                                        : 11.0.5600.12
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.1
  Driver Setup Program                                : 2.19
  
  Windows 2000/XP Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.48
  Vista driver Version: 5.10.0.5317
    1. Vista logo Codec Supporting: ALC882, ALC883, ALC885, ALC888, ALC861VD, ALC660, ALC662, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows Vista x86/x64
    
  Vista driver for x86                                : 6.10.0.5317
  RtHDVCpl.exe                                        : 1.0.0.6
  RtkAPO.dll                                          : 11.0.5600.12
  RtkPgExt.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSndMgr.cpl                                        : 1.0.0.1
  Vista driver for x64                                : 6.10.0.5317
  RAVCpl64.exe                                        : 1.0.0.6
  RtkAPO64.dll                                        : 11.0.5600.12
  RtPgEx64.dll                                        : 6.0.5600.12
  RTCOMDLL.dll                                        : 1.0.0.63
  RtlCPAPI.dll                                        : 1.0.0.7
  RTSnMg64.cpl                                        : 1.0.0.1
  Driver Setup Program                                : 2.19
//=================
Driver Package R1.47
  RtkHDAud.sys Version: 5.10.0.5296
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5296
  WDM driver for Winx64                               : 5.10.0.5296
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.9.8
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.18
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.46
  RtkHDAud.sys Version: 5.10.0.5294
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5294
  WDM driver for Winx64                               : 5.10.0.5294
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.9.6
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.16
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.45
  RtkHDAud.sys Version: 5.10.0.5288
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5288
  WDM driver for Winx64                               : 5.10.0.5288
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.9
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.9.1
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.44
  RtkHDAud.sys Version: 5.10.0.5286
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5286
  WDM driver for Winx64                               : 5.10.0.5286
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.8.7
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.43
  RtkHDAud.sys Version: 5.10.0.5283
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5283
  WDM driver for Winx64                               : 5.10.0.5283
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.8.3
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.42
  RtkHDAud.sys Version: 5.10.0.5282
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Fix some game issue .

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5282
  WDM driver for Winx64                               : 5.10.0.5282
  Realtek Soundman			   	      : 1.0.0.30
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.8.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.41
  RtkHDAud.sys Version: 5.10.0.5273
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.  

       CPL :
        1.) Customization.
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5273
  WDM driver for Winx64                               : 5.10.0.5273
  Realtek Soundman			   	      : 1.0.0.29
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.7.3
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.14
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.40
  RtkHDAud.sys Version: 5.10.0.5268
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD, ALC660, ALC260, ALC262, ALC268
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
                 
       InstallShield package :
        1.) Correct present driver version in "Add or Remove Programs \ Support Information" .
        2.) Windows 2000 installation reboot twice problem .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5268
  WDM driver for Winx64                               : 5.10.0.5268
  Realtek Soundman			   	      : 1.0.0.29
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.7.0
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.14
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.39
  RtkHDAud.sys Version: 5.10.0.5265
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC861VD,ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
        2.) Add support for left panel and right panel config.
         
       InstallShield package :
        1.) Copy file rule in Vista system .
        2.) Show driver version in "Add or Remove Programs \ Support Information" .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5265
  WDM driver for Winx64                               : 5.10.0.5265
  Realtek Soundman			   	      : 1.0.0.29
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.6.9
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.13
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.38
  RtkHDAud.sys Version: 5.10.0.5257
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
         
       InstallShield package :
        1.) Add "XP2K" and "Vista" folder name for installation .
        2.) Abort flag setting .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5257
  WDM driver for Winx64                               : 5.10.0.5257
  Realtek Soundman			   	      : 1.0.0.29
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.6.6
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.11
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.37
  RtkHDAud.sys Version: 5.10.0.5253
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .

       CPL :
        1.) Customization.
         
       InstallShield package :
        1.) Upgrade to IS11.5 .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5253
  WDM driver for Winx64                               : 5.10.0.5253
  Realtek Soundman			   	      : 1.0.0.29
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.64
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.6.4
  Alcwzrd.exe 				              : 1.1.0.36
  SkyTel.exe                                          : 1.0.0.0
  Driver Setup Program                                : 2.09
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.36
  RtkHDAud.sys Version: 5.10.0.5247
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC888, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Add ALC888 .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5247
  WDM driver for Winx64                               : 5.10.0.5247
  Realtek Soundman			   	      : 1.0.0.28
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.62
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.5.9
  Alcwzrd.exe 				              : 1.1.0.35
  Driver Setup Program                                : 2.06
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.35
  RtkHDAud.sys Version: 5.10.0.5242
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5242
  WDM driver for Winx64                               : 5.10.0.5242
  Realtek Soundman			   	      : 1.0.0.28
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.62
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.5.4
  Alcwzrd.exe 				              : 1.1.0.35
  Driver Setup Program                                : 2.06
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.34
  RtkHDAud.sys Version: 5.10.0.5233
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Fixed Adobe Premiere Pro 1.5 Crash issue .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
        1.) Rtlupd termination return error code .
        2.) Receive error code rule from Rtlupd SetupAPI .
        3.) SetupCopyOEM install rule .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5233
  WDM driver for Winx64                               : 5.10.0.5233
  Realtek Soundman			   	      : 1.0.0.28
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.62
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.4.9
  Alcwzrd.exe 				              : 1.1.0.35
  Driver Setup Program                                : 2.06
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.33
  RtkHDAud.sys Version: 5.10.0.5229
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
        1.) Bus driver detect issue .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5229
  WDM driver for Winx64                               : 5.10.0.5229
  Realtek Soundman			   	      : 1.0.0.28
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.61
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.4.7
  Alcwzrd.exe 				              : 1.1.0.34
  Driver Setup Program                                : 2.05
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.32
  RtkHDAud.sys Version: 5.10.0.5224
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
        1.) Report installation progress and result to "C:\RTHSetup.log" within silent mode .
        2.) Rtlupd setup API will not appear message dialog in silent mode .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5224
  WDM driver for Winx64                               : 5.10.0.5224
  Realtek Soundman			   	      : 1.0.0.28
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.61
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.4.4
  Alcwzrd.exe 				              : 1.1.0.34
  Driver Setup Program                                : 2.04
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.31
  RtkHDAud.sys Version: 5.10.0.5221
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC885, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Add ALC885 HD Audio Codec for WHQL .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5221
  WDM driver for Winx64                               : 5.10.0.5221
  Realtek Soundman			   	      : 1.0.0.27
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.60
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.4.2
  Alcwzrd.exe 				              : 1.1.0.33
  Driver Setup Program                                : 2.03
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.30
  RtkHDAud.sys Version: 5.10.0.5211
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization .
        2.) Bug fixed when recording AEC device failed on 880 .
       
       CPL :
        1.) Customization.
         
       InstallShield package :
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5211
  WDM driver for Winx64                               : 5.10.0.5211
  Realtek Soundman			   	      : 1.0.0.24
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.8
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.58
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.3.9
  Alcwzrd.exe 				              : 1.1.0.31
  Driver Setup Program                                : 2.03
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.29
  RtkHDAud.sys Version: 5.10.0.5202
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.
       
       CPL :
        1.) Customization.
         
       InstallShield package :
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5202
  WDM driver for Winx64                               : 5.10.0.5202
  Realtek Soundman			   	      : 1.0.0.21
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.54
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.3.4
  Alcwzrd.exe 				              : 1.1.0.29
  Driver Setup Program                                : 2.02c
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.28
  RtkHDAud.sys Version: 5.10.0.5200
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.
        2.) Add ALC265 .
       
       CPL :
        1.) Side speaker testing has no sound when 3D engine is disabled.
         
       InstallShield package :
        1.) Add Chipset ID VEN_1002&DEV_4383 .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5200
  WDM driver for Winx64                               : 5.10.0.5200
  Realtek Soundman			   	      : 1.0.0.21
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.53
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.3.2
  Alcwzrd.exe 				              : 1.1.0.28
  Driver Setup Program                                : 2.02c
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.27
  RtkHDAud.sys Version: 5.10.0.5188
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.
         
       InstallShield package :
           Fix :
             1. Add installation file "RTHDAEQ*.dat" .
             2. Add Package version in setup.ini .
             3. Manual installation setting for InstallShield .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5188
  WDM driver for Winx64                               : 5.10.0.5188
  Realtek Soundman			   	      : 1.0.0.21
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.53
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.2.6
  Alcwzrd.exe 				              : 1.1.0.28
  Driver Setup Program                                : 2.02a
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.26
  RtkHDAud.sys Version: 5.10.0.5178
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.
         
       InstallShield package :
           Fix :
             1. Set rebooting twice for installation UAA QFE on Win2000 .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5178
  WDM driver for Winx64                               : 5.10.0.5178
  Realtek Soundman			   	      : 1.0.0.21
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.6
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.52
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.2.1
  Alcwzrd.exe 				              : 1.1.0.28
  Driver Setup Program                                : 2.00
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.25
  RtkHDAud.sys Version: 5.10.0.5172
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
        1.) Customization.
         
       InstallShield package :
           Fix :
             1. Rtlupd.exe(2.5.0.5) fixed roll-back problem ( It can not delete oem.inf file before update driver ).
             2. Change Azalia name in setup.ini file .
             3. Don't popup Rtlupd dialog when you select "No" on Hotfix installation dialog .
           Add :
             1. System language identifier .
             2. Change pop-up dialog Product name ( Azalia->High Definition ) . 
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5172
  WDM driver for Winx64                               : 5.10.0.5172
  Realtek Soundman			   	      : 1.0.0.21
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.10
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.6
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.51
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.1.7
  Alcwzrd.exe 				              : 1.1.0.27
  Driver Setup Program                                : 1.99
 
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.24
  RtkHDAud.sys Version: 5.10.0.5152
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
         1.) Customization.
         2.) Support 192KHz sample rate output.
         
       InstallShield package :
           Fix : 
             1. Reboot timing after installation MS QFE ( UAA driver ) .
             2. Uninstallation dialog description .
           Add :
             1. MS hotfix KB901105 can be included by HD pcakage ( If get MS licence ) .
             2. Hotfix KB901105 Warning message .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5152
  WDM driver for Winx64                               : 5.10.0.5152
  Realtek Soundman			   	      : 1.0.0.18
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.4
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.46
  Realtek Sound Effect Manager(RTHDCPL)               : 2.0.0.8
  Alcwzrd.exe 				              : 1.1.0.24
  Driver Setup Program                                : 1.96
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.23
  RtkHDAud.sys Version: 5.10.0.5136
    1. Codec Supporting: ALC880, ALC882, ALC883, ALC861, ALC260, ALC262
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
         1.) Customization.
         2.) Support new codec ALC262, ALC883
         
       InstallShield package :
         1.) Check OS service pack number with InstallShield .
         2.) Change audio wizard quitting procedure .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5136
  WDM driver for Winx64                               : 5.10.0.5136
  Realtek Soundman			   	      : 1.0.0.17
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.4
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.43
  Realtek Sound Effect Manager(RTHDCPL)               : 1.1.2.3
  Alcwzrd.exe 				              : 1.1.0.23
  Driver Setup Program                                : 1.92
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.22
  RtkHDAud.sys Version: 5.10.0.5128
    1. Codec Supporting: ALC880, ALC882, ALC861, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
         1.) Customization.
         
       InstallShield package :
         1.) Setup progress backward .
         2.) Driver size on Add and remove programs .
         3.) Refresh driver size on Add and Remove Programs .
         4.) Check RtlExupd.dll version .
         5.) Check RtlHDCpl.exe version .
      
  WDM driver for Win2000/WinXP                        : 5.10.0.5128
  WDM driver for Winx64                               : 5.10.0.5128
  Realtek Soundman			   	      : 1.0.0.17
  Realtek Sound Effect Manager(ALSndMgr.cpl)          : 1.0.0.7
  Realtek Sound Effect Manager(RTSndMgr.cpl)          : 1.0.0.4
  Realtek Sound Effect Manager(RtlCpl)                : 1.0.1.40
  Realtek Sound Effect Manager(RTHDCPL)               : 1.1.1.9
  Alcwzrd.exe 				              : 1.1.0.20
  Driver Setup Program                                : 1.91
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.21
  RtkHDAud.sys Version: 5.10.0.5127
    1. Codec Supporting: ALC880, ALC882, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
         1.) Customization.
         2.) Support DTS Encoder and DTS Neo for special version codec .
      
  SoundMan.exe Version: 1.0.0.17
  ALSndMgr.cpl Version: 1.0.0.7  
  Rtlcpl.exe Version: 1.0.1.40	
  Alcwzrd.exe Version: 1.1.0.20
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.20
  RtkHDAud.sys Version: 5.10.0.5125
    1. Codec Supporting: ALC880, ALC882, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1.) Customization.    
     
       For New architecture:
         1.) Customization.
         2.) Fixed the issue of SPDIF-In capture
      
  SoundMan.exe Version: 1.0.0.17
  ALSndMgr.cpl Version: 1.0.0.7  
  Rtlcpl.exe Version: 1.0.1.40	
  Alcwzrd.exe Version: 1.1.0.20
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.19
  RtkHDAud.sys Version: 5.10.0.5123
    1. Codec Supporting: ALC880, ALC882, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000, Winx64
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1. Customization.    
	2. Avoid Pop noise when toggle output sampling rate for ALC260.
	3. Restore the original timer resolution first before check the original system timer resolution.
     
       For New architecture:
         1.) Customization.
         2.) Driver store mixer setting after windows reboot
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.39	
  Alcwzrd.exe Version: 1.1.0.19
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.18
  RtkHDAud.sys Version: 5.10.0.5122
    1. Codec Supporting: ALC880, ALC882, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1. Customization.
	2.Add 2 default values of codec subsystem ID for ALC260.
      
       For New architecture:
         1.) Customization.
         2.) Fixed the issue of uncontinuous sound after suspend on some machine.
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.38	
  Alcwzrd.exe Version: 1.1.0.18
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.17
  RtkHDAud.sys Version: 5.10.0.5120
    1. Codec Supporting: ALC880, ALC882, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
        1. Customization.
        2. Restore certain register value when resume from system suspend. 
      
       For New architecture:
         1.) Customization.
         2.) Improve reliability for switching multiple streaming.
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.38	
  Alcwzrd.exe Version: 1.1.0.18
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.16
  RtkHDAud.sys Version: 5.10.0.5119
    1. Codec Supporting: ALC880, ALC882, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1.0a(5013)
    4. Add/Fix
       1. Customization.
       2. Fix initial noise issue for the certain models.
       3. Check codec SubsystemID verb to decide the driver path when driver initialize.
       4. Don't modify Configuration byte Verbs when driver initialize.
       5. Fix Buffer size un-alignment issue.
       
       For New architecture:
         1.) Customization.
         2.) Fix the problem when play AC-3 stream by SPDIF interface
         3.) Change device name for multiple streaming issue.
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.38	
  Alcwzrd.exe Version: 1.1.0.17
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB888111
      Package file version (kb888111.exe) : 6.1.22.0
      Hdaudiobus.sys version : 5.10.00.5013
//=================
Driver Package R1.15
  RtkHDAud.sys Version: 5.10.0.5116
    1. Codec Supporting: ALC880, ALC882, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
       1.) Customization.
       2.) Auto lock SPDIF-in signal when SPDIF-in signal is unlocked.
       3.) Fix SPDIF out copy protection issue.
       4.) Add patch code for ALC260 potential risk.
 
       For New architecture:
         1.) Customization.
         2.) Fix new feature problem on multiple streaming.
         3.) Fix capture problem on ALC882.
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.38	
  Alcwzrd.exe Version: 1.1.0.17
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.14
  RtkHDAud.sys Version: 5.10.0.5109
    1. Codec Supporting: ALC880, ALC882, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
       1.) Customization.
       2.) Reduce delay time when volume is adjusted.
       3.) Fix hang up issue when system resume from S3.
 
       For New architecture:
         1.) New architecture of HD audio driver formal release.
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.4  
  Rtlcpl.exe Version: 1.0.1.37	
  Alcwzrd.exe Version: 1.1.0.16
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.13
  RtkHDAud.sys Version: 5.10.0.5038
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
     1) Reduce initialize noise
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.36	
  Alcwzrd.exe Version: 1.1.0.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.12
  RtkHDAud.sys Version: 5.10.0.5037
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
     1) Improve recording performance.
     2) Reduce initialize noise
      
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.36	
  Alcwzrd.exe Version: 1.1.0.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.11
  RtkHDAud.sys Version: 5.10.0.5036
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
     
  SoundMan.exe Version: 1.0.0.14
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.35	
  Alcwzrd.exe Version: 1.1.0.15
  
  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.10
  RtkHDAud.sys Version: 5.10.0.5034
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio UAAV1(5011)
    4. Add/Fix
     1) Fix the problem that there is little noise when start stream playing
     2) Fix the problem that in WinDVD, the SPDIF option still exist even 
        there is no SPDIF
    
  
  SoundMan.exe Version: 1.0.0.14
   1.Set the default recording device as "Realtek HD Audio rear input" device 

  ALSndMgr.cpl Version: 1.0.0.5
  
  Rtlcpl.exe Version: 1.0.1.34
	
  Alcwzrd.exe Version: 1.1.0.15
   1.Keep previous Jack setting.
   2.Check whether have any jack plugin when restart OS,and popup the 
     device window if wizard detect any new device plugin.

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5011
//=================
Driver Package R1.09
  RtkHDAud.sys Version: 5.10.0.5033
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
     
  SoundMan.exe Version: 1.0.0.14
    1.Set the default recording device as "Realtek HD Audio rear input" device 
  	
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.33   
  Alcwzrd.exe Version: 1.1.0.14

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010
//=================
Driver Package R1.08
  RtkHDAud.sys Version: 5.10.0.5032
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
      
  SoundMan.exe Version: 1.0.0.12 	
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.33   
  Alcwzrd.exe Version: 1.1.0.14

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010
//=================
Driver Package R1.07
  RtkHDAud.sys Version: 5.10.0.5031
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
     1) Fix the problem when playback with sound recorder, when change frequency
        from 48k to 44.1k in SPDIF page, playback will stop
     2) Support for ALC880G, ALC880D, ALC260D
     3) Fix the the problem that system will hang up while perform audio test 
        in 3DMark 2003
  
  SoundMan.exe Version: 1.0.0.12  	
  ALSndMgr.cpl Version: 1.0.0.5
  
  Rtlcpl.exe Version: 1.0.1.32
  1.Fix word collision problem in Multi-Language.
   
  Alcwzrd.exe Version: 1.1.0.13
  1.Restore previous jack setting when reboot system.

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010
//=================
Driver Package R1.06
  RtkHDAud.sys Version: 5.10.0.5030
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
  
  SoundMan.exe Version: 1.0.0.12  	
  ALSndMgr.cpl Version: 1.0.0.3 
  Rtlcpl.exe Version: 1.0.1.31   
  Alcwzrd.exe Version: 1.1.0.12

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010
//=================
Driver Package R1.05
  RtkHDAud.sys Version: 5.10.0.5029
    1. Codec Supporting: ALC880, ALC260, ALC861
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
     1) Add support for ALC861
     2) Fix the noise problem that when recording from SPDIF In at 96khz
  
  SoundMan.exe Version: 1.0.0.12  	
  ALSndMgr.cpl Version: 1.0.0.5  
  Rtlcpl.exe Version: 1.0.1.31   
  Alcwzrd.exe Version: 1.1.0.12

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010
//=================
Driver Package R1.04
  RtkHDAud.sys Version: 5.10.0.5028
    1. Codec Supporting: ALC880, ALC260
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
     1) For UAJ A to A volume line, change type from KSNODETYPE_MICROPHONE 
        to KSNODETYPE_ANALOG_CONNECTOR
     2) Fix the problem that SPDIF out no sound in WinDVD
     3) Fix the problem that there is balance control in Center and 
        Subwoofer volume line in W2k
     4) Change the component tyep of SPDIF-In from "KSNODETYPE_ANALOG_CONNECTOR" 
        to "KSNODETYPE_SPDIF_INTERFACE"
     5) Fix the problem that mute SPDIF out in mixer doesn't work
  
  SoundMan.exe Version: 1.0.0.12 	
  ALSndMgr.cpl Version: 1.0.0.3
  
  Rtlcpl.exe Version: 1.0.1.31
   1.Turn off all sound effect when speaker test!
   
  Alcwzrd.exe Version: 1.1.0.12

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010

//=================
Driver Package R1.03
  RtkHDAud.sys Version: 5.10.0.5027
  SoundMan.exe Version: 1.0.0.4
  ALSndMgr.cpl Version: 1.0.0.2
  
  Rtlcpl.exe Version: 1.0.1.29
   1.Sync the status which Enable/Disable wizard with alcwzrd
   2.Make the tab of "Audio Wizard" independent from  menu tabs.
   3.Stop the play sound when menu tab is change.
   
  Alcwzrd.exe Version: 1.1.0.12
    1.Fixed broken wizard image.
    2.Sync the status which Enable/Disable wizard with rtlcpl.

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010

//=================
Driver Package R1.01/R1.02
  RtkHDAud.sys Version: 5.10.0.5022
    1. Codec Supporting:
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
 
  SoundMan.exe Version: 1.0.0.4
  ALSndMgr.cpl Version: 1.0.0.2
  Rtlcpl.exe Version: 1.0.1.23
   
  Alcwzrd.exe Version: 1.1.0.5

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010

//=================
Driver Package R1.0
  RtkHDAud.sys Version: 5.10.0.5017
    1. Codec Supporting: Add ALC880/ALC880M Rev.F Rev.G, ALC860
    2. OS Supporting: Microsoft Windows XP, Windows 2000
    3. Pack with Microsoft High Definition Audio OOB Binaries V1.0
    4. Add/Fix
 
  SoundMan.exe Version: 1.0.0.4
  ALSndMgr.cpl Version: 1.0.0.2
  Rtlcpl.exe Version: 1.0.1.23
   
  Alcwzrd.exe Version: 1.1.0.5

  Operate on :
    Microsoft High Definition Audio Driver Package - KB835221
      Package file version (kb835221.exe) : 6.1.1.0
      Hdaudiobus.sys version : 5.10.00.5010